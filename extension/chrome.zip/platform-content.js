(() => {
  const CONTENT_SCRIPT_LOAD_ID = "platform-content-2026-07-10-destination-sheet-polish";
  const BUBBLE_ID = "context-generator-bubble";
  const OVERLAY_ID = "context-generator-overlay";
  const ONBOARDING_ID = "context-generator-onboarding";
  const ONBOARDING_STYLE_ID = "context-generator-onboarding-styles";
  const CLAUDE_LIMIT_NUDGE_ID = "context-generator-claude-limit-nudge";
  const DESTINATION_SHEET_ID = "context-generator-destination-sheet";
  const DESTINATION_SHEET_STYLE_ID = "context-generator-destination-sheet-styles";
  const LAST_TRANSFER_STATS_STORAGE_KEY = "context-generator-last-transfer-stats-v1";

  if (window.__contextGeneratorPlatformLoaded === CONTENT_SCRIPT_LOAD_ID) {
    return;
  }

  cleanupContextGeneratorNodes();

  const extensionRuntime = getExtensionRuntime();
  if (!extensionRuntime) {
    console.warn("[Context Generator] Extension runtime is unavailable; skipping content script startup.");
    return;
  }

  window.__contextGeneratorPlatformLoaded = CONTENT_SCRIPT_LOAD_ID;

  const BUBBLE_SIZE = 42;
  const BUBBLE_GAP = 8;
  const BUBBLE_SLOT_WIDTH = BUBBLE_SIZE + BUBBLE_GAP + 6;
  const CLAUDE_INLINE_SLOT_WIDTH = BUBBLE_SIZE + 62;
  const CLAUDE_INLINE_BUBBLE_GAP = 46;
  const CLAUDE_INLINE_RIGHT_MARGIN = 4;
  const CLAUDE_MODEL_LEFT_NUDGE = 48;
  const CLAUDE_SIDE_CONTROL_RIGHT_NUDGE = 52;
  const DESTINATION_SHEET_WIDTH = 376;
  const RUNNING_AUTO_RESET_MS = 240000;
  const MAX_BACKEND_CONVERSATION_CHARS = 160000;
  const BACKEND_CONVERSATION_HEAD_CHARS = 32000;
  const BACKEND_CONVERSATION_OMISSION_MARKER = "[...middle of conversation omitted to fit the backup summarizer...]";
  const DEFAULT_MAX_COMPOSER_WIDTH = 1320;
  const DESTINATION_TITLE_TEXT = "Where to continue?";
  const DESTINATION_HELPER_TEXT = "Context goes straight into the input box";
  const ONBOARDING_STORAGE_KEY = "context-generator-onboarding-dismissed-v2";
  const ONBOARDING_TITLE_TEXT = "Transfer chat context";
  const ONBOARDING_BODY_TEXT = "From this button.";
  const CLAUDE_LIMIT_NUDGE_TEXT = "Claude's brilliant. Claude's also broke by message 20. We've got you covered. Tap to continue in another AI with context.";
  const ONBOARDING_SHOW_DELAY_MS = 650;
  const NO_CONVERSATION_ERROR_TITLE = "Nothing to carry yet";
  const NO_CONVERSATION_ERROR_MESSAGE = "Chat is empty. Send one message first, then I'll pack the context.";
  const SUMMARY_RETRY_ERROR_TITLE = "Try again";
  const SUMMARY_RETRY_ERROR_MESSAGE = "Try again right now. We might have made a mistake. It almost never happens the second time.";
  const MIN_FALLBACK_CONVERSATION_CHARS = 120;
  const CONVERSATION_SCRAPE_RETRY_TIMEOUT_MS = 0;
  const CLAUDE_CONVERSATION_SCRAPE_RETRY_TIMEOUT_MS = 1800;
  const CONVERSATION_SCRAPE_RETRY_INTERVAL_MS = 140;
  const SOURCE_SCROLL_STABLE_TIMEOUT_MS = 1800;
  const SOURCE_SCROLL_LONG_STABLE_TIMEOUT_MS = 4500;
  const SOURCE_SCROLL_STABLE_INTERVAL_MS = 140;
  const SOURCE_SCROLL_STABLE_SAMPLE_COUNT = 3;
  const VIRTUAL_SWEEP_PLATFORM_IDS = new Set(["claude", "chatgpt", "gemini", "grok", "deepseek"]);
  const VIRTUAL_SWEEP_MIN_TURNS = 8;
  const VIRTUAL_SWEEP_MAX_SCROLLS = 480;
  const VIRTUAL_SWEEP_STALE_SCROLLS = 3;
  const CLAUDE_VIRTUAL_SWEEP_STALE_SCROLLS = 10;
  const VIRTUAL_SWEEP_STEP_RATIO = 0.6;
  const VIRTUAL_SWEEP_SETTLE_MS = 360;
  const VIRTUAL_SWEEP_STABLE_SAMPLE_COUNT = 2;
  const VIRTUAL_SWEEP_CHANGE_POLL_MS = 40;
  const VIRTUAL_SWEEP_ANCHOR_CHANGE_TIMEOUT_MS = 80;
  const VIRTUAL_SWEEP_FAST_CHANGE_TIMEOUT_MS = 120;
  const VIRTUAL_SWEEP_SLOW_CHANGE_TIMEOUT_MS = 360;
  const CLAUDE_VIRTUAL_SWEEP_SLOW_CHANGE_TIMEOUT_MS = 1400;
  const COLLAPSED_CONVERSATION_EXPAND_RE = /\b(?:show|see|read|view)\s+(?:more|full|all)\b|\bcontinue\s+(?:reading|message|response)\b|\bexpand\b/i;
  const COLLAPSED_CONVERSATION_EXPAND_EXCLUDE_RE = /\b(?:continue generating|regenerate|send|submit|stop generating|new chat|settings|menu|voice|microphone)\b/i;
  const EMPTY_START_SCREEN_TEXTS = [
    "the mic is yours",
    "start chatting",
    "message chatgpt",
    "message claude",
    "message deepseek",
    "ask gemini",
    "ask grok",
    "ask anything",
    "ask me anything",
    "new chat",
    "what can i help with",
    "what can i help you with",
    "how can i help",
    "how can i help you today",
    "what are you working on",
    "where should we begin",
    "try asking",
    "suggested prompts"
  ];
  const PASTE_RETRY_TIMEOUT_MS = 22000;
  const CHATGPT_PASTE_RETRY_TIMEOUT_MS = 32000;
  const PASTE_RETRY_INTERVAL_MS = 180;
  const PASTE_VERIFY_TIMEOUT_MS = 1000;
  const CHATGPT_PASTE_VERIFY_TIMEOUT_MS = 1500;
  const CHATGPT_PASTE_STABILITY_MS = 550;
  const WARM_SUMMARY_EXPIRES_AT = Number.POSITIVE_INFINITY;
  const HANDOFF_STATUS_INTERVAL_MS = 1850;
  const HANDOFF_COUNTDOWN_ID = "context-generator-handoff-countdown";
  const HANDOFF_COUNTDOWN_FIXED_MS = 20000;
  const HANDOFF_QUOTES = [
    "I don't like waiting 20 seconds either.",
    "The wait is for better context.",
    "A few seconds now saves re-explaining later.",
    "Better context, cleaner next reply.",
    "Holding the useful bits together.",
    "Worth it when the next AI starts warm."
  ];
  const HANDOFF_STATUS_STEPS = [
    "I don't like waiting either",
    "This is for better context",
    "Keeping the thread intact",
    "Saving you the re-explain",
    "Making the next reply sharper",
    "Almost ready"
  ];
  const GENERIC_CONVERSATION_SELECTORS = [
    "[data-message-author-role]",
    "[data-testid*='conversation' i]",
    "[data-testid*='message' i]",
    "[data-testid*='chat' i]",
    "[data-role*='message' i]",
    "[class*='message' i]",
    "[class*='markdown' i]",
    "article"
  ];
  const FALLBACK_CONVERSATION_ROOT_SELECTORS = [
    "main",
    "[role='main']",
    "[data-testid*='conversation' i]",
    "[data-testid*='chat' i]",
    "[data-testid*='thread' i]",
    "[class*='conversation' i]",
    "[class*='messages' i]",
    "[class*='message-list' i]",
    "[class*='thread' i]",
    "[class*='chat' i]"
  ];
  const SOURCE_SCROLL_ROOT_SELECTORS = [
    "main",
    "[role='main']",
    "[class*='overflow-y-auto' i]",
    "[class*='overflow-auto' i]",
    "[class*='scroll' i]",
    "[data-testid*='conversation' i]",
    "[data-testid*='thread' i]",
    "[data-testid*='chat' i]",
    "[class*='conversation' i]",
    "[class*='messages' i]",
    "[class*='message-list' i]",
    "[class*='thread' i]",
    "[class*='chat' i]"
  ];
  const CAP_CONTEXT_SITE_URL = "https://spidey889.github.io/context-generator";
  const EXTENSION_ASSET_BASE_URL = getRuntimeAssetBaseUrl();
  const BUBBLE_ICON_URL = getExtensionAssetUrl("bubble-icon.png");

  const PLATFORMS = {
    claude: {
      name: "Claude",
      detail: "Anthropic",
      host: "claude.ai",
      url: "https://claude.ai/",
      accent: "#d97757",
      logoSize: 24,
      logo: "logos/claude2download__1_-removebg-preview.png",
      retryPaste: true,
      inputSelectors: [
        "textarea",
        "[contenteditable='true'][data-placeholder]",
        "[contenteditable='true'][aria-label*='prompt' i]",
        "[contenteditable='true'][aria-label*='message' i]",
        "[contenteditable='true']"
      ],
      fallbackSelectors: ["textarea", "[contenteditable='true']"],
      conversationSelectors: [
        "[data-testid*='user-message' i]",
        "[data-testid*='assistant-message' i]",
        "[data-message-author-role]",
        ".font-claude-response"
      ]
    },
    chatgpt: {
      name: "ChatGPT",
      detail: "OpenAI",
      host: "chatgpt.com",
      alternateHosts: ["openai.com"],
      url: "https://chatgpt.com/",
      accent: "#19c37d",
      logoSize: 21,
      logo: "logos/gptwhitedownload__1_-removebg-preview.png",
      retryPaste: true,
      pasteRetryTimeoutMs: CHATGPT_PASTE_RETRY_TIMEOUT_MS,
      pasteVerifyTimeoutMs: CHATGPT_PASTE_VERIFY_TIMEOUT_MS,
      pasteStabilityMs: CHATGPT_PASTE_STABILITY_MS,
      maxComposerWidth: 1120,
      composerSelectors: [
        "form",
        "div[class*='composer' i]",
        "[data-testid*='composer' i]",
        "[data-type*='composer' i]"
      ],
      inputSelectors: [
        "#prompt-textarea[contenteditable='true']",
        "[data-testid='prompt-textarea'][contenteditable='true']",
        ".ProseMirror[contenteditable='true']",
        "div[contenteditable='true'][role='textbox']",
        "[contenteditable='true'][data-placeholder]",
        "[contenteditable='true'][aria-label*='message' i]",
        "[contenteditable='true']"
      ],
      fallbackSelectors: [
        "#prompt-textarea",
        "[data-testid='prompt-textarea']",
        "textarea[placeholder]",
        "textarea"
      ],
      conversationSelectors: [
        "[data-message-author-role]",
        "[data-testid^='conversation-turn']",
        "article",
        ".markdown"
      ]
    },
    gemini: {
      name: "Gemini",
      detail: "Google",
      host: "gemini.google.com",
      url: "https://gemini.google.com/",
      accent: "#8ab4f8",
      logoSize: 22,
      logo: "logos/gemini-download__1_-removebg-preview.png",
      retryPaste: true,
      maxComposerWidth: 1080,
      composerSelectors: [
        "div[class*='input-area-container' i]",
        "div[class*='input-area' i]",
        "div[class*='prompt-input' i]",
        "div[class*='text-input' i]",
        "prompt-input",
        "rich-textarea",
        "form"
      ],
      inputSelectors: [
        ".ql-editor[contenteditable='true']",
        "rich-textarea [contenteditable='true']",
        "div[contenteditable='true'][aria-label*='prompt' i]",
        "div[contenteditable='true'][role='textbox']",
        "[contenteditable='true'][data-placeholder]",
        "[contenteditable='true']"
      ],
      fallbackSelectors: [
        "rich-textarea textarea",
        "textarea[aria-label*='prompt' i]",
        "textarea[placeholder]",
        "textarea"
      ],
      conversationSelectors: [
        "user-query",
        "model-response",
        "message-content",
        "[data-test-id*='conversation' i]",
        "[class*='query-text' i]",
        "[class*='response-content' i]"
      ]
    },
    grok: {
      name: "Grok",
      detail: "xAI",
      host: "grok.com",
      url: "https://grok.com/",
      accent: "#f5f5f5",
      logoSize: 24,
      logo: "logos/grokwhitedownload__1_-removebg-preview.png",
      retryPaste: true,
      inputSelectors: [
        "[data-testid='grokInput'][contenteditable='true']",
        "[data-testid='grok-input'][contenteditable='true']",
        "[data-testid*='composer' i] [contenteditable='true']",
        "[data-testid*='prompt' i][contenteditable='true']",
        "[aria-label*='ask grok' i][contenteditable='true']",
        "div[contenteditable='true'][aria-label*='ask' i]",
        "div[contenteditable='true'][role='textbox']",
        "[contenteditable='true'][data-placeholder]",
        "[contenteditable='true']"
      ],
      fallbackSelectors: [
        "[data-testid='grokInput'] textarea",
        "[data-testid='grok-input'] textarea",
        "textarea[data-testid='grokInput']",
        "textarea[data-testid='grok-input']",
        "textarea[aria-label*='ask grok' i]",
        "textarea[placeholder*='ask grok' i]",
        "textarea[placeholder*='ask' i]",
        "textarea[aria-label*='ask' i]",
        "textarea[placeholder]",
        "textarea"
      ],
      conversationSelectors: [
        "[data-testid*='message' i]",
        "[class*='message' i]",
        "article"
      ]
    },
    deepseek: {
      name: "DeepSeek",
      detail: "DeepSeek",
      host: "chat.deepseek.com",
      url: "https://chat.deepseek.com/",
      accent: "#4c8dff",
      logoSize: 22,
      logo: "logos/deepseek-download__1_-removebg-preview.png",
      retryPaste: true,
      maxComposerWidth: 1140,
      composerSelectors: [
        "div[class*='input-container' i]",
        "div[class*='chat-input' i]",
        "div[class*='input-box' i]",
        "div[class*='composer' i]",
        "div[class*='textarea' i]",
        "form"
      ],
      inputSelectors: [
        "#chat-input[contenteditable='true']",
        "[data-testid*='chat-input' i][contenteditable='true']",
        "[data-testid*='composer' i] [contenteditable='true']",
        "div[contenteditable='true'][aria-label*='message' i]",
        "div[contenteditable='true'][aria-label*='ask' i]",
        "div[contenteditable='true'][role='textbox']",
        "[contenteditable='true'][data-placeholder]",
        "[contenteditable='true']"
      ],
      fallbackSelectors: [
        "textarea[name='search']",
        "#chat-input",
        "textarea[aria-label*='message' i]",
        "textarea[aria-label*='ask' i]",
        "textarea[placeholder*='message' i]",
        "textarea[placeholder*='ask' i]",
        "textarea[placeholder]",
        "textarea"
      ],
      conversationSelectors: [
        ".ds-markdown",
        "[class*='message' i]",
        "[class*='chat-item' i]",
        "[data-role]"
      ]
    }
  };

  const currentPlatform = getCurrentPlatform();
  if (!currentPlatform) {
    return;
  }

  let isRunning = false;
  let runningResetTimer = null;
  let reservedActionCluster = null;
  let reservedClaudeInlineControls = [];
  let reservedClaudeInlineShift = 0;
  let reservedClaudeControlOffsets = new Map();
  let reservedClaudeOverflowElements = [];
  let reservedComposerSurface = null;
  let destinationSheetAnimationFrame = null;
  let floatingButtonFrame = null;
  let floatingButtonObserver = null;
  let floatingButtonMonitoringDisabled = false;
  let warmSummary = null;
  let handoffStatusTimer = null;
  let handoffCountdownTimer = null;
  let handoffCountdownHideTimer = null;
  let handoffStatusIndex = 0;
  let onboardingTimer = null;
  let onboardingDismissedThisSession = false;
  let claudeLimitNudgeDismissedUntilLimitClears = false;
  let activeTransferTrace = null;
  let transferTraceSequence = 0;
  let lastConversationCaptureMetrics = null;

  function cleanupContextGeneratorNodes() {
    cleanupContextGeneratorReservations();

    [
      BUBBLE_ID,
      OVERLAY_ID,
      ONBOARDING_ID,
      ONBOARDING_STYLE_ID,
      CLAUDE_LIMIT_NUDGE_ID,
      DESTINATION_SHEET_ID,
      DESTINATION_SHEET_STYLE_ID,
      "context-generator-styles",
      "context-generator-error-overlay",
      "context-generator-error-mark",
      "context-generator-fallback-modal"
    ].forEach((id) => document.getElementById(id)?.remove());
  }

  function cleanupContextGeneratorReservations() {
    document.querySelectorAll("[data-context-generator-original-transform]").forEach((element) => {
      element.style.transform = element.getAttribute("data-context-generator-original-transform") || "";
      element.style.willChange = "";
      element.removeAttribute("data-context-generator-original-transform");
    });

    document.querySelectorAll("[data-context-generator-original-overflow]").forEach((element) => {
      element.style.overflow = element.getAttribute("data-context-generator-original-overflow") || "";
      element.removeAttribute("data-context-generator-original-overflow");
    });

    document.querySelectorAll("[data-context-generator-original-position]").forEach((element) => {
      element.style.position = element.getAttribute("data-context-generator-original-position") || "";
      element.removeAttribute("data-context-generator-original-position");
    });
  }

  extensionRuntime.onMessage.addListener((message, _sender, sendResponse) => {
    if (message?.type === "CONTEXT_GENERATOR_PING") {
      sendResponse({ ok: true });
      return false;
    }

    if (message?.type === "PASTE_CONTEXT") {
      const pasteStartedAt = getNow();
      logTransferPerf(message.transferId, "destination paste start", { destination: message.destination });
      pasteIntoPlatform(message.text, message.destination, message.transferId)
        .then(() => {
          const pasteMs = Math.round(getNow() - pasteStartedAt);
          logTransferPerf(message.transferId, "destination paste done", { destination: message.destination, pasteMs });
          sendResponse({ ok: true, timing: { pasteMs } });
        })
        .catch((error) => sendResponse({ ok: false, error: error.message }));

      return true;
    }

    if (message?.type === "START_CONTEXT_TRANSFER") {
      if (isRunning) {
        sendResponse({ ok: false, error: "Context transfer is already running." });
        return false;
      }

      const destination = message.destination || getDefaultDestinationId();
      isRunning = true;
      clearRunningResetTimer();
      runningResetTimer = setTimeout(resetRunningFlag, RUNNING_AUTO_RESET_MS);
      sendResponse({ ok: true });
      const trace = createTransferTrace(destination, "extension icon");
      markTransferTrace(trace, "click", { source: "extension icon" });
      runContextFlow(destination, null, null, null, trace);
      return false;
    }

    return false;
  });

  if (window.__CONTEXT_GENERATOR_TEST_HOOKS__?.register) {
    window.__CONTEXT_GENERATOR_TEST_HOOKS__.register({
      scrapeConversationText,
      getConversationRole,
      editorContainsText,
      getVerificationSamples,
      normalizeVerificationText,
      getClaudeBubblePlacement,
      getGeminiBubblePlacement,
      findGeminiModelSelectorButton,
      limitConversationText,
      getConversationFingerprint,
      getSummaryForTransfer,
      prepareSourceForCapture,
      waitForConversationCaptureToSettle,
      expandCollapsedConversationContent,
      getConversationTurns,
      scrapeConversationTextWhenReady,
      scrapeConversationTextForTransfer,
      getClaudeInlineControlsToShift,
      getClaudeModelControlsToNudge,
      getClaudeControlTargetOffset,
      reserveClaudeInlineBubbleSlot
    });
  } else {
    startFloatingButtonMonitoring();
  }

  async function runContextFlow(destinationId, preparedDestinationPromise = null, warmSummaryRecord = null, scrapedConversationText = null, trace = null) {
    const transferTrace = trace || createTransferTrace(destinationId, "transfer");
    transferTrace.destinationId = destinationId;
    let transferStage = "capture";
    let summary = "";
    try {
      const destination = getPlatform(destinationId);
      let conversationText = scrapedConversationText;
      let destinationPrepPromise = preparedDestinationPromise;
      if (!conversationText) {
        if (isHandoffOverlayVisible()) {
          setHandoffStatus("Reading source chat");
        } else {
          showOverlay(destinationId);
        }
        await prepareSourceForCapture();
        if (!destinationPrepPromise && getDetectedConversationMessageCount() > 0) {
          destinationPrepPromise = prepareDestinationTab(destinationId, transferTrace);
        }
        transferStage = "capture";
        markTransferTrace(transferTrace, "capture start");
        conversationText = await scrapeConversationTextWhenReady();
        markCaptureDone(transferTrace, conversationText);
      }
      destinationPrepPromise = destinationPrepPromise || prepareDestinationTab(destinationId, transferTrace);
      if (isHandoffOverlayVisible()) {
        setHandoffStatus("Summarizing context");
      } else {
        showOverlay(destinationId);
      }
      transferStage = "summary";
      summary = await getSummaryForTransfer(conversationText, warmSummaryRecord, transferTrace);
      markTransferTrace(transferTrace, "summary available", { chars: summary.length });
      setHandoffStatus(`Preparing ${destination?.name || "destination"}`);
      transferStage = "destination";
      const preparedDestination = destinationPrepPromise ? await destinationPrepPromise : null;
      markTransferTrace(transferTrace, "tab open done", {
        tabId: preparedDestination?.tabId || null,
        background: preparedDestination?.timing || null
      });
      setHandoffStatus(`Pasting context into ${destination?.name || "destination"}`);
      markTransferTrace(transferTrace, "paste request start");
      transferStage = "paste";
      const pasteResponse = await notifyBackground({
        type: "TRANSFER_TO_DESTINATION",
        destination: destinationId,
        text: summary,
        preparedTabId: preparedDestination?.tabId || null,
        transferId: transferTrace.id
      });
      appendBackgroundMarks(transferTrace, pasteResponse?.marks);
      markTransferTrace(transferTrace, "paste done", pasteResponse?.timing || null);
      finishTransferTrace(transferTrace);
      resetRunningFlag();
    } catch (error) {
      markTransferTrace(transferTrace, `failed: ${error.message}`);
      finishTransferTrace(transferTrace);
      resetRunningFlag();
      showContextTransferFailure(error, {
        destinationId,
        stage: transferStage,
        summary
      });
      await notifyBackground({ type: "CONTEXT_TRANSFER_ERROR", error: error.message }).catch(() => {});
    }
  }

  function showContextTransferFailure(error, details = {}) {
    const stage = details.stage || "transfer";
    const summary = details.summary?.trim?.() || "";
    const destinationName = getPlatform(details.destinationId)?.name || "the destination";

    if (stage === "summary") {
      showErrorOverlay(SUMMARY_RETRY_ERROR_MESSAGE);
      return;
    }

    if (summary) {
      showFallbackModal(summary, destinationName);
      return;
    }

    showErrorOverlay(error?.message || "Transfer failed. Please try again.");
  }

  async function summarizeWithBackend(conversationText, trace = null) {
    return (await requestBackendSummary(conversationText, trace)).summary;
  }

  async function requestBackendSummary(conversationText, trace = null) {
    markTransferTrace(trace, "summary start", { chars: conversationText.length, inputChars: conversationText.length });
    const response = await notifyBackground({
      type: "SUMMARIZE_WITH_BACKEND",
      conversation: conversationText,
      transferId: trace?.id || null
    });

    if (!response?.summary?.trim()) {
      throw new Error("Backup summarizer returned no summary.");
    }

    const summary = response.summary.trim();
    const timing = response.timing || null;
    markTransferTrace(trace, "summary done", {
      chars: summary.length,
      background: timing
    });
    return { summary, timing };
  }

  async function getSummaryForTransfer(conversationText, warmSummaryRecord = null, trace = null) {
    const fingerprint = getConversationFingerprint(conversationText);
    const candidate = warmSummaryRecord || warmSummary;

    if (isWarmSummaryUsable(candidate, fingerprint)) {
      const summary = candidate.summary || await candidate.promise;
      if (summary && candidate.fingerprint === fingerprint) {
        const targetTrace = trace || candidate.trace;
        const summaryTiming = candidate.summaryTiming || getSummaryTimingFromTrace(candidate.trace);
        if (targetTrace && summaryTiming && !getSummaryTimingFromTrace(targetTrace)) {
          markTransferTrace(targetTrace, "summary done", {
            chars: summary.length,
            background: summaryTiming
          });
        }
        markTransferTrace(targetTrace, "summary reused", {
          source: candidate.summary ? "completed warm summary" : "warm summary promise",
          chars: summary.length
        });
        clearWarmSummary();
        return summary;
      }
    }

    if (candidate) clearWarmSummary();
    return summarizeWithBackend(conversationText, trace);
  }

  function startSheetOpenWarmSummary() {
    if (isRunning) return;
    const trace = createTransferTrace(null, "Cap-Context button");
    activeTransferTrace = trace;
    markTransferTrace(trace, "click", { source: "Cap-Context button" });
    const record = startWarmSummary(null, trace);
    if (!record) activeTransferTrace = null;
    return record;
  }

  function scheduleWarmSummary() {
    return startSheetOpenWarmSummary();
  }

  function startWarmSummary(conversationText = null, trace = null) {
    if (isRunning) return;

    if (!conversationText) {
      try {
        markTransferTrace(trace, "capture start");
        conversationText = scrapeConversationText();
        markCaptureDone(trace, conversationText);
      } catch (error) {
        logTransferDebug(`Warm summary skipped. ${error.message}`);
        return null;
      }
    }

    const fingerprint = getConversationFingerprint(conversationText);
    if (isWarmSummaryUsable(warmSummary, fingerprint)) return warmSummary;

    clearWarmSummary();
    const record = {
      fingerprint,
      startedAt: Date.now(),
      expiresAt: WARM_SUMMARY_EXPIRES_AT,
      summary: null,
      summaryTiming: null,
      promise: null,
      settled: false,
      trace
    };

    record.promise = requestBackendSummary(conversationText, trace)
      .then((result) => {
        record.settled = true;
        const summary = result.summary;
        record.summaryTiming = result.timing;
        if (warmSummary === record) {
          record.summary = summary;
        }
        return summary;
      })
      .catch((error) => {
        record.settled = true;
        if (warmSummary === record) {
          logTransferDebug(`Warm summary failed. ${error.message}`);
          clearWarmSummary();
        }
        return null;
      });

    warmSummary = record;
    return record;
  }

  function ensureWarmSummaryForConversation(conversationText, trace = null) {
    const fingerprint = getConversationFingerprint(conversationText);
    if (isWarmSummaryUsable(warmSummary, fingerprint)) return warmSummary;

    return startWarmSummary(conversationText, trace);
  }

  function isWarmSummaryUsable(record, fingerprint) {
    return Boolean(
      record &&
      record.fingerprint === fingerprint &&
      (Date.now() <= record.expiresAt || (record.promise && !record.settled))
    );
  }

  function clearWarmSummary() {
    warmSummary = null;
  }

  function getConversationFingerprint(text) {
    const cleaned = cleanText(text);
    return `${cleaned.length}:${cleaned.slice(0, 180)}:${cleaned.slice(-220)}`;
  }

  function prepareDestinationTab(destinationId, trace = null) {
    markTransferTrace(trace, "tab open start", { destination: destinationId });
    return notifyBackground({
      type: "PREPARE_DESTINATION",
      destination: destinationId,
      transferId: trace?.id || null
    }).then((response) => {
      markTransferTrace(trace, "tab open response", {
        tabId: response?.tabId || null,
        background: response?.timing || null
      });
      return response;
    }).catch((error) => {
      logTransferDebug(`Destination pre-open failed; falling back to normal transfer. ${error.message}`);
      return null;
    });
  }

  function createTransferTrace(destinationId, source) {
    transferTraceSequence += 1;
    const id = `${Date.now().toString(36)}-${transferTraceSequence}`;
    return {
      id,
      source,
      sourcePlatformId: currentPlatform.id,
      sourcePlatformName: currentPlatform.name,
      destinationId,
      startedAt: getNow(),
      startedAtEpoch: Date.now(),
      lastAt: null,
      marks: [],
      completed: false
    };
  }

  function markCaptureDone(trace, conversationText) {
    markTransferTrace(trace, "capture done", {
      chars: conversationText.length,
      ...getConversationCaptureMetrics(conversationText)
    });
  }

  async function prepareSourceForCapture() {
    scrollSourceConversationToTop();
    await waitForConversationCaptureToSettle();
    const expandedCount = await expandCollapsedConversationContent();
    if (expandedCount > 0) {
      await waitForConversationCaptureToSettle(Math.min(1200, getSourceScrollStableTimeout()));
    }
  }

  async function waitForConversationCaptureToSettle(timeoutMs = getSourceScrollStableTimeout()) {
    const startedAt = Date.now();
    let lastSnapshot = getConversationReadinessSnapshot();
    let stableSamples = 0;

    while (Date.now() - startedAt < timeoutMs) {
      const remainingMs = timeoutMs - (Date.now() - startedAt);
      await delay(Math.min(SOURCE_SCROLL_STABLE_INTERVAL_MS, Math.max(0, remainingMs)));
      scrollSourceConversationToTop();

      const expandedCount = await expandCollapsedConversationContent();
      const nextSnapshot = getConversationReadinessSnapshot();
      if (expandedCount === 0 && isConversationReadinessStable(lastSnapshot, nextSnapshot)) {
        stableSamples += 1;
        if (stableSamples >= SOURCE_SCROLL_STABLE_SAMPLE_COUNT) return;
      } else {
        lastSnapshot = nextSnapshot;
        stableSamples = 0;
      }
    }
  }

  function getSourceScrollStableTimeout() {
    return currentPlatform.id === "claude" || currentPlatform.id === "chatgpt"
      ? SOURCE_SCROLL_LONG_STABLE_TIMEOUT_MS
      : SOURCE_SCROLL_STABLE_TIMEOUT_MS;
  }

  function getConversationReadinessSnapshot() {
    const messageTurns = getConversationTurns().filter((turn) => isDetectedConversationMessage(turn));
    const scrollState = getSourceScrollState();
    return {
      count: messageTurns.length,
      chars: messageTurns.reduce((total, turn) => total + turn.text.length, 0),
      scrollHeight: scrollState.scrollHeight,
      scrollTop: scrollState.scrollTop
    };
  }

  function isConversationReadinessStable(previous, next) {
    return (
      previous.count === next.count &&
      previous.chars === next.chars &&
      previous.scrollHeight === next.scrollHeight &&
      next.scrollTop <= 2
    );
  }

  function getDetectedConversationMessageCount() {
    return getConversationTurns().filter((turn) => isDetectedConversationMessage(turn)).length;
  }

  function scrollSourceConversationToTop() {
    getSourceScrollTargets().forEach(scrollElementToTopInstantly);
    scrollWindowToTopInstantly();
  }

  function getSourceScrollState() {
    return getSourceScrollTargets().reduce((state, element) => {
      state.scrollHeight += Number(element.scrollHeight || 0);
      state.scrollTop += Number(element.scrollTop || 0);
      state.clientHeight += Number(element.clientHeight || 0);
      return state;
    }, {
      scrollHeight: 0,
      scrollTop: Math.max(0, Number(window.scrollY || 0)),
      clientHeight: Math.max(0, Number(window.innerHeight || 0))
    });
  }

  function getSourceScrollRemaining() {
    const elementRemaining = getSourceScrollTargets().reduce((remaining, element) => {
      const maxTop = getElementMaxScrollTop(element);
      const currentTop = Math.max(0, Number(element.scrollTop || 0));
      return Math.max(remaining, maxTop - currentTop);
    }, 0);

    return Math.max(elementRemaining, getWindowScrollRemaining());
  }

  function getElementMaxScrollTop(element) {
    return Math.max(0, Number(element?.scrollHeight || 0) - Number(element?.clientHeight || 0));
  }

  function getWindowScrollRemaining() {
    const documentHeight = Math.max(
      Number(document.documentElement?.scrollHeight || 0),
      Number(document.body?.scrollHeight || 0)
    );
    const viewportHeight = Number(window.innerHeight || document.documentElement?.clientHeight || 0);
    if (!documentHeight || !viewportHeight) return 0;
    return Math.max(0, documentHeight - viewportHeight - Math.max(0, Number(window.scrollY || 0)));
  }

  function getSourceViewportHeight() {
    const targetHeight = getSourceScrollTargets().reduce((height, element) => {
      return Math.max(height, Number(element.clientHeight || 0));
    }, 0);
    return Math.max(360, targetHeight || Number(window.innerHeight || 0) || 720);
  }

  function scrollSourceConversationByInstantly(deltaY) {
    let moved = false;
    getSourceScrollTargets().forEach((element) => {
      if (scrollElementByInstantly(element, deltaY)) moved = true;
    });
    if (scrollWindowByInstantly(deltaY)) moved = true;
    return moved;
  }

  function scrollElementByInstantly(element, deltaY) {
    const maxTop = getElementMaxScrollTop(element);
    const currentTop = Math.max(0, Number(element.scrollTop || 0));
    if (maxTop <= 0 || currentTop >= maxTop - 1) return false;

    const nextTop = Math.min(maxTop, currentTop + Math.max(1, Number(deltaY || 0)));
    try {
      element.scrollTo?.({ top: nextTop, left: element.scrollLeft || 0, behavior: "instant" });
    } catch {
      try {
        element.scrollTo?.(element.scrollLeft || 0, nextTop);
      } catch {}
    }
    if (Math.abs(Number(element.scrollTop || 0) - nextTop) > 1) {
      try {
        element.scrollTop = nextTop;
      } catch {}
    }

    return Math.abs(Number(element.scrollTop || 0) - currentTop) > 1;
  }

  function scrollWindowByInstantly(deltaY) {
    if (getWindowScrollRemaining() <= 1) return false;
    const currentTop = Math.max(0, Number(window.scrollY || 0));
    const nextTop = currentTop + Math.max(1, Number(deltaY || 0));
    try {
      window.scrollTo?.({ top: nextTop, left: window.scrollX || 0, behavior: "instant" });
    } catch {
      try {
        window.scrollTo?.(window.scrollX || 0, nextTop);
      } catch {}
    }
    return Math.abs(Number(window.scrollY || 0) - currentTop) > 1;
  }

  async function waitForConversationWindowToSettle(
    timeoutMs = VIRTUAL_SWEEP_SETTLE_MS,
    stableSampleCount = VIRTUAL_SWEEP_STABLE_SAMPLE_COUNT
  ) {
    const startedAt = Date.now();
    let lastSnapshot = getConversationReadinessSnapshot();
    let stableSamples = 0;

    while (Date.now() - startedAt < timeoutMs) {
      const remainingMs = timeoutMs - (Date.now() - startedAt);
      await delay(Math.min(SOURCE_SCROLL_STABLE_INTERVAL_MS, Math.max(0, remainingMs)));

      const expandedCount = await expandCollapsedConversationContent();
      const nextSnapshot = getConversationReadinessSnapshot();
      if (expandedCount === 0 && isConversationWindowStable(lastSnapshot, nextSnapshot)) {
        stableSamples += 1;
        if (stableSamples >= stableSampleCount) return;
      } else {
        lastSnapshot = nextSnapshot;
        stableSamples = 0;
      }
    }
  }

  function isConversationWindowStable(previous, next) {
    return (
      previous.count === next.count &&
      previous.chars === next.chars &&
      previous.scrollHeight === next.scrollHeight &&
      previous.scrollTop === next.scrollTop
    );
  }

  async function expandCollapsedConversationContent(maxRounds = 3) {
    let expandedCount = 0;

    for (let round = 0; round < maxRounds; round += 1) {
      const expanders = getCollapsedConversationExpanders();
      if (!expanders.length) break;

      expanders.slice(0, 30).forEach((element) => {
        try {
          element.click?.();
          expandedCount += 1;
        } catch (error) {
          console.debug("[Context Generator] Could not expand collapsed conversation text:", error?.message || error);
        }
      });

      await delay(80);
    }

    return expandedCount;
  }

  function getCollapsedConversationExpanders() {
    return Array.from(document.querySelectorAll("button, [role='button'], summary"))
      .filter((element, index, all) => all.indexOf(element) === index && isCollapsedConversationExpander(element));
  }

  function isCollapsedConversationExpander(element) {
    if (!(element instanceof Element) || !isVisible(element) || isContextGeneratorNode(element)) return false;
    if (element.closest("nav, header, footer, aside, menu")) return false;

    const label = getElementLabel(element, true);
    if (!COLLAPSED_CONVERSATION_EXPAND_RE.test(label)) return false;
    if (COLLAPSED_CONVERSATION_EXPAND_EXCLUDE_RE.test(label)) return false;

    return Boolean(
      element.closest(getConversationReadinessSelectors()) ||
      element.closest("main, [role='main']")
    );
  }

  function getSourceScrollTargets() {
    const roots = [
      document.scrollingElement,
      document.documentElement,
      document.body
    ];
    const rootSelectors = [
      ...SOURCE_SCROLL_ROOT_SELECTORS,
      ...FALLBACK_CONVERSATION_ROOT_SELECTORS
    ];
    const selectors = [
      ...currentPlatform.conversationSelectors,
      ...GENERIC_CONVERSATION_SELECTORS,
      ...FALLBACK_CONVERSATION_ROOT_SELECTORS
    ];

    document.querySelectorAll([...new Set(rootSelectors)].join(",")).forEach((element) => {
      if (isLikelySourceScrollRoot(element)) roots.push(element);
    });

    document.querySelectorAll([...new Set(selectors)].join(",")).forEach((element) => {
      let node = element;
      while (node && node !== document.body && node !== document.documentElement) {
        if (isScrollableSourceElement(node)) roots.push(node);
        node = node.parentElement;
      }
    });

    return roots.filter((element, index, all) => element && all.indexOf(element) === index);
  }

  function isLikelySourceScrollRoot(element) {
    if (!isScrollableSourceElement(element)) return false;
    if (element.closest("nav, header, footer, aside, menu")) return false;

    const rect = element.getBoundingClientRect?.();
    if (rect && (rect.height < 160 || rect.width < 260)) return false;

    const label = getElementLabel(element);
    return /\b(?:main|conversation|conversations|thread|threads|chat|chats|messages|message-list|transcript|scroll|overflow)\b/.test(label);
  }

  function isScrollableSourceElement(element) {
    if (!(element instanceof Element) || isContextGeneratorNode(element)) return false;
    const scrollHeight = Number(element.scrollHeight || 0);
    const clientHeight = Number(element.clientHeight || 0);
    return scrollHeight > clientHeight + 4;
  }

  function scrollElementToTopInstantly(element) {
    try {
      element.scrollTop = 0;
      element.scrollTo?.({ top: 0, left: element.scrollLeft || 0, behavior: "instant" });
    } catch {
      try {
        element.scrollTo?.(element.scrollLeft || 0, 0);
      } catch {}
    }
  }

  function scrollWindowToTopInstantly() {
    try {
      window.scrollTo?.({ top: 0, left: window.scrollX || 0, behavior: "instant" });
    } catch {
      try {
        window.scrollTo?.(window.scrollX || 0, 0);
      } catch {}
    }
  }

  function markTransferTrace(trace, label, detail = null) {
    if (!trace) return;
    const now = getNow();
    const previous = trace.lastAt || trace.startedAt;
    const mark = {
      label,
      at: now,
      deltaMs: Math.round(now - previous),
      totalMs: Math.round(now - trace.startedAt),
      detail
    };
    trace.lastAt = now;
    trace.marks.push(mark);
    logTransferPerf(trace.id, label, {
      totalMs: mark.totalMs,
      deltaMs: mark.deltaMs,
      ...formatTraceDetail(detail)
    });
  }

  function finishTransferTrace(trace) {
    if (!trace || trace.completed) return;
    trace.completed = true;
    const totalMs = Math.round(getNow() - trace.startedAt);
    persistLatestTransferStats(trace, totalMs);
    const rows = trace.marks.map((mark) => ({
      step: mark.label,
      deltaMs: mark.deltaMs,
      totalMs: mark.totalMs,
      detail: JSON.stringify(formatTraceDetail(mark.detail))
    }));
    console.debug(`[Context Generator Perf ${trace.id}] total ${totalMs}ms`, rows);
    if (activeTransferTrace === trace) {
      activeTransferTrace = null;
    }
  }

  function formatTraceDetail(detail) {
    if (!detail || typeof detail !== "object") return {};
    return Object.fromEntries(Object.entries(detail).filter(([, value]) => value !== undefined && value !== null));
  }

  function logTransferPerf(id, label, detail = null) {
    const suffix = detail ? ` ${JSON.stringify(formatTraceDetail(detail))}` : "";
    console.debug(`[Context Generator Perf ${id || "no-trace"}] ${label}${suffix}`);
  }

  function getActiveTransferTraceForConversation(conversationText) {
    const fingerprint = getConversationFingerprint(conversationText);
    if (isWarmSummaryUsable(warmSummary, fingerprint) && warmSummary.trace) {
      return warmSummary.trace;
    }
    if (activeTransferTrace) return activeTransferTrace;
    return createTransferTrace(null, "destination tile");
  }

  function appendBackgroundMarks(trace, marks = []) {
    if (!trace || !Array.isArray(marks)) return;
    marks.forEach((mark) => {
      logTransferPerf(trace.id, `background: ${mark.label}`, {
        totalMs: mark.totalMs,
        deltaMs: mark.deltaMs,
        ...(mark.detail || {})
      });
    });
  }

  function persistLatestTransferStats(trace, totalMs) {
    const storage = chrome?.storage?.local;
    if (!storage?.set) return;

    const stats = buildLatestTransferStats(trace, totalMs);
    const setResult = storage.set({ [LAST_TRANSFER_STATS_STORAGE_KEY]: stats });
    if (setResult?.catch) {
      setResult.catch((error) => {
        console.debug("[Context Generator] Could not save latest analysis stats:", error?.message || error);
      });
    }
  }

  function buildLatestTransferStats(trace, totalMs) {
    const summaryTiming = getSummaryTimingFromTrace(trace);
    const backendTiming = summaryTiming?.backend || null;
    const captureDetail = getMarkDetail(trace, "capture done") || {};
    const pasteDetail = getMarkDetail(trace, "paste done") || {};
    const failureMark = trace.marks.find((mark) => mark.label.startsWith("failed:"));

    return {
      version: 1,
      transferId: trace.id,
      status: failureMark ? "failed" : "completed",
      failure: failureMark?.label.replace(/^failed:\s*/, "") || null,
      source: {
        id: trace.sourcePlatformId,
        name: trace.sourcePlatformName
      },
      destination: {
        id: trace.destinationId || null,
        name: trace.destinationId ? getPlatform(trace.destinationId)?.name || trace.destinationId : null
      },
      startedAt: new Date(trace.startedAtEpoch || Date.now()).toISOString(),
      completedAt: new Date().toISOString(),
      totalMs,
      capture: {
        method: captureDetail.method || null,
        messageTurnCount: captureDetail.messageTurnCount ?? null,
        usefulTurnCount: captureDetail.usefulTurnCount ?? null,
        rawCandidateChars: captureDetail.rawCandidateChars ?? null,
        transcriptChars: captureDetail.transcriptChars ?? null,
        cleanedChars: captureDetail.cleanedChars ?? null,
        sentChars: captureDetail.sentChars ?? captureDetail.chars ?? null,
        capped: captureDetail.capped === true,
        capChars: captureDetail.capChars || MAX_BACKEND_CONVERSATION_CHARS
      },
      summary: {
        source: summaryTiming?.source || null,
        summaryMs: summaryTiming?.summaryMs ?? null,
        fetchMs: summaryTiming?.fetchMs ?? null,
        parseMs: summaryTiming?.parseMs ?? null,
        outputChars: summaryTiming?.chars ?? backendTiming?.outputChars ?? null,
        requestChars: summaryTiming?.requestChars ?? null,
        backendInputChars: summaryTiming?.backendInputChars ?? backendTiming?.inputChars ?? null,
        backendTotalMs: backendTiming?.totalMs ?? null,
        mistralMs: backendTiming?.mistralMs ?? null,
        groqMs: backendTiming?.groqMs ?? null,
        providerMs: backendTiming?.providerMs ?? null,
        providerPasses: backendTiming?.providerPasses ?? null,
        servedBy: backendTiming?.servedBy || backendTiming?.provider || null,
        provider: backendTiming?.provider || backendTiming?.servedBy || null,
        primaryModel: backendTiming?.primaryModel || null,
        model: backendTiming?.model || null,
        modelReason: backendTiming?.modelReason || null,
        mistralModelsTried: sanitizeModelChainForStats(backendTiming?.mistralModelsTried),
        modelInputChars: backendTiming?.modelInputChars ?? null,
        modelThresholdChars: backendTiming?.modelThresholdChars ?? null,
        modelOverride: backendTiming?.modelOverride === true,
        profile: backendTiming?.profile || null,
        maxTokens: backendTiming?.maxTokens ?? null,
        targetWords: backendTiming?.targetWords ?? null,
        minWords: backendTiming?.minWords ?? null,
        summaryWordCount: backendTiming?.summaryWordCount ?? null,
        mistralPasses: backendTiming?.mistralPasses ?? null,
        expansion: sanitizeExpansionForStats(backendTiming?.expansion),
        fallback: sanitizeFallbackForStats(backendTiming?.fallback),
        usage: normalizeUsageForStats(backendTiming?.usage)
      },
      destinationTiming: {
        totalMs: pasteDetail.totalMs ?? null,
        pasteMs: pasteDetail.paste?.pasteMs ?? pasteDetail.pasteMs ?? null,
        tabId: pasteDetail.tabId ?? null
      },
      timeline: trace.marks.map((mark) => ({
        label: mark.label,
        deltaMs: mark.deltaMs,
        totalMs: mark.totalMs,
        detail: sanitizeTraceDetail(formatTraceDetail(mark.detail))
      }))
    };
  }

  function getSummaryTimingFromTrace(trace) {
    if (!trace?.marks) return null;
    const summaryDone = [...trace.marks].reverse().find((mark) => mark.label === "summary done");
    return summaryDone?.detail?.background || null;
  }

  function getMarkDetail(trace, label) {
    return [...trace.marks].reverse().find((mark) => mark.label === label)?.detail || null;
  }

  function sanitizeExpansionForStats(expansion) {
    if (!expansion || typeof expansion !== "object") return null;
    return {
      attempted: expansion.attempted === true,
      used: expansion.used === true,
      wordCount: expansion.wordCount ?? null,
      error: expansion.error ? "Expansion failed" : null,
      usage: normalizeUsageForStats(expansion.usage)
    };
  }

  function sanitizeFallbackForStats(fallback) {
    if (!fallback || typeof fallback !== "object") return null;
    return {
      attempted: fallback.attempted === true,
      used: fallback.used === true,
      servedBy: fallback.servedBy || null,
      model: fallback.model || null,
      reason: fallback.reason || null
    };
  }

  function sanitizeModelChainForStats(models) {
    if (!Array.isArray(models)) return [];
    return models
      .filter((model) => typeof model === "string" && model.trim())
      .slice(0, 3)
      .map((model) => model.trim());
  }

  function normalizeUsageForStats(usage) {
    if (!usage || typeof usage !== "object") return null;
    return {
      promptTokens: usage.promptTokens ?? null,
      completionTokens: usage.completionTokens ?? null,
      totalTokens: usage.totalTokens ?? null,
      cachedTokens: usage.cachedTokens ?? null
    };
  }

  function sanitizeTraceDetail(detail) {
    if (!detail || typeof detail !== "object") return {};
    const sanitized = { ...detail };
    delete sanitized.backend;
    delete sanitized.background;
    return sanitized;
  }

  function getNow() {
    return window.performance?.now?.() || Date.now();
  }

  async function notifyBackground(message) {
    let response;
    try {
      response = await extensionRuntime.sendMessage(message);
    } catch (error) {
      if (isExtensionContextInvalidated(error)) {
        throw new Error("Extension was reloaded. Refresh this AI tab once, then try Cap-Context again.");
      }
      throw error;
    }

    if (response && response.ok === false) {
      throw new Error(response.error || "Unknown background error");
    }
    return response;
  }

  function getRuntimeAssetBaseUrl() {
    try {
      return extensionRuntime?.getURL?.("") || "";
    } catch (_error) {
      return "";
    }
  }

  function getExtensionRuntime() {
    try {
      const runtime = globalThis.chrome?.runtime;
      if (!runtime?.onMessage?.addListener || !runtime?.sendMessage) return null;
      return runtime;
    } catch (_error) {
      return null;
    }
  }

  function getExtensionAssetUrl(path) {
    if (!EXTENSION_ASSET_BASE_URL) return "";
    return `${EXTENSION_ASSET_BASE_URL}${path}`;
  }

  function isExtensionContextInvalidated(error) {
    return /extension context invalidated/i.test(error?.message || "");
  }

  function getDefaultDestinationId() {
    return currentPlatform.id === "chatgpt" ? "claude" : "chatgpt";
  }

  function getCurrentPlatform() {
    const hostname = window.location.hostname;
    return Object.entries(PLATFORMS)
      .map(([id, platform]) => ({ ...platform, id }))
      .find((platform) => hostMatches(hostname, platform));
  }

  function hostMatches(hostname, platform) {
    const hosts = [platform.host, ...(platform.alternateHosts || [])];
    return hosts.some((host) => hostname === host || hostname.endsWith(`.${host}`));
  }

  function getPlatform(platformId) {
    const platform = PLATFORMS[platformId];
    return platform ? { ...platform, id: platformId } : null;
  }

  async function pasteIntoPlatform(text, destinationId, transferId = null) {
    const destination = getPlatform(destinationId) || currentPlatform;
    if (!destination) {
      throw new Error("This AI destination is not supported.");
    }

    if (!text?.trim()) {
      throw new Error(`No text was provided for ${destination.name}.`);
    }

    const trimmedText = text.trim();

    if (destination.retryPaste) {
      await pasteWithRetry(trimmedText, destination, transferId);
      return;
    }

    const input = await waitForElement(() => findPlatformInput(destination), 15000, `${destination.name} message input`);
    if (!input) {
      showFallbackModal(trimmedText, destination.name);
      throw new Error(`${destination.name} message input element could not be found.`);
    }

    logTransferPerf(transferId, "destination input ready", { destination: destination.name });
    setEditorText(input, trimmedText, destination);

    if (!editorContainsText(input, trimmedText)) {
      showFallbackModal(trimmedText, destination.name);
      throw new Error(`Paste operation failed to populate the ${destination.name} editor.`);
    }

    input.focus?.();
  }

  async function pasteWithRetry(text, destination, transferId = null) {
    const startedAt = Date.now();
    const retryTimeoutMs = destination.pasteRetryTimeoutMs || PASTE_RETRY_TIMEOUT_MS;
    const verifyTimeoutMs = destination.pasteVerifyTimeoutMs || PASTE_VERIFY_TIMEOUT_MS;
    const stabilityMs = destination.pasteStabilityMs || 0;
    let sawInput = false;
    let loggedInputReady = false;
    let lastError = null;

    while (Date.now() - startedAt <= retryTimeoutMs) {
      const input = findReadyPlatformInput(destination);
      if (input) {
        sawInput = true;
        if (!loggedInputReady) {
          loggedInputReady = true;
          logTransferPerf(transferId, "destination input ready", {
            destination: destination.name,
            readyMs: Date.now() - startedAt
          });
        }

        try {
          setEditorText(input, text, destination);

          if (await waitForEditorText(input, text, verifyTimeoutMs)) {
            if (stabilityMs > 0) {
              await delay(stabilityMs);
              if (!editorContainsText(input, text)) {
                lastError = new Error(`${destination.name} editor cleared the pasted context after first insert.`);
                continue;
              }
            }
            input.focus?.();
            return input;
          } else {
            lastError = new Error(`Paste operation failed to populate the ${destination.name} editor.`);
          }
        } catch (error) {
          lastError = error;
        }
      }

      await delay(PASTE_RETRY_INTERVAL_MS);
    }

    showFallbackModal(text, destination.name);

    if (!sawInput) {
      throw new Error(`${destination.name} message input element could not be found.`);
    }

    throw lastError || new Error(`Paste operation failed to populate the ${destination.name} editor.`);
  }

  function findPlatformInput(platform = currentPlatform) {
    const selectors = [...platform.inputSelectors, ...platform.fallbackSelectors];
    const candidates = selectors
      .flatMap((selector) => Array.from(document.querySelectorAll(selector)))
      .filter((element, index, all) => {
        return all.indexOf(element) === index && isVisible(element) && !element.closest("[aria-hidden='true']");
      });

    return candidates
      .map((element) => ({ element, score: scoreInputCandidate(element) }))
      .sort((a, b) => b.score - a.score)[0]?.element || null;
  }

  function findReadyPlatformInput(platform = currentPlatform) {
    const input = findPlatformInput(platform);
    return isEditorReady(input) ? input : null;
  }

  function isEditorReady(element) {
    if (!element || !isVisible(element) || isDisabled(element)) return false;

    if (element instanceof HTMLTextAreaElement || element instanceof HTMLInputElement) {
      return !element.readOnly;
    }

    return element.isContentEditable && element.getAttribute("contenteditable") !== "false";
  }

  function scoreInputCandidate(element) {
    const rect = element.getBoundingClientRect();
    const label = getElementLabel(element);

    let score = 0;
    if (element instanceof HTMLTextAreaElement || element instanceof HTMLInputElement) score += 24;
    if (element.isContentEditable) score += 20;
    if (element.closest("form")) score += 48;
    if (/\b(message|prompt|chat|write|ask|input)\b/.test(label)) score += 72;
    if (rect.width >= 240) score += 24;
    if (rect.height >= 18 && rect.height <= 280) score += 18;
    if (rect.bottom >= window.innerHeight * 0.45) score += 56;
    if (rect.bottom >= window.innerHeight * 0.7) score += 32;
    if (rect.top < 120 && rect.bottom < window.innerHeight * 0.45) score -= 90;

    return score;
  }

  function setEditorText(element, text, destination = currentPlatform) {
    element.click();
    element.focus();

    if (element instanceof HTMLTextAreaElement || element instanceof HTMLInputElement) {
      const valueSetter = Object.getOwnPropertyDescriptor(element.constructor.prototype, "value")?.set;
      valueSetter?.call(element, text);
      dispatchEditorEvents(element, text);
      return;
    }

    if (destination?.id === "chatgpt") {
      setChatGptEditorText(element, text);
      return;
    }

    const target = element.querySelector("p") || element;
    const selection = window.getSelection();
    const range = document.createRange();
    range.selectNodeContents(target);
    selection.removeAllRanges();
    selection.addRange(range);

    let inserted = document.execCommand("insertText", false, text);
    let hasText = editorContainsText(element, text);

    if (!inserted || !hasText) {
      element.focus();
      document.execCommand("selectAll", false, null);
      inserted = document.execCommand("insertText", false, text);
      hasText = editorContainsText(element, text);
    }

    if (!hasText) {
      target.textContent = text;
      hasText = editorContainsText(element, text);
    }

    if (!hasText) {
      element.textContent = text;
    }

    dispatchEditorEvents(target, text);
    if (target !== element) dispatchEditorEvents(element, text);
  }

  function setChatGptEditorText(element, text) {
    selectEditorContents(element);
    dispatchBeforeInputPasteEvent(element, text);

    if (!editorContainsText(element, text)) {
      selectEditorContents(element);
      dispatchClipboardPasteEvent(element, text);
    }

    if (!editorContainsText(element, text)) {
      selectEditorContents(element);
      document.execCommand("insertText", false, text);
    }

    if (!editorContainsText(element, text)) {
      document.execCommand("selectAll", false, null);
      document.execCommand("insertText", false, text);
    }

    if (!editorContainsText(element, text)) {
      element.textContent = text;
    }

    dispatchEditorEvents(element, text);
  }

  function selectEditorContents(element) {
    const selection = window.getSelection();
    const range = document.createRange();
    range.selectNodeContents(element);
    selection.removeAllRanges();
    selection.addRange(range);
  }

  function dispatchBeforeInputPasteEvent(element, text) {
    try {
      element.dispatchEvent(new InputEvent("beforeinput", {
        bubbles: true,
        cancelable: true,
        inputType: "insertFromPaste",
        data: text
      }));
    } catch {
      element.dispatchEvent(new Event("beforeinput", { bubbles: true, cancelable: true }));
    }
  }

  function dispatchClipboardPasteEvent(element, text) {
    let clipboardData = null;
    try {
      clipboardData = new DataTransfer();
      clipboardData.setData("text/plain", text);
    } catch (_error) {
      return;
    }

    try {
      element.dispatchEvent(new ClipboardEvent("paste", {
        bubbles: true,
        cancelable: true,
        clipboardData
      }));
    } catch (_error) {
      // Some browsers ignore synthetic clipboard payloads. execCommand fallback follows.
    }
  }

  function dispatchEditorEvents(element, text) {
    try {
      element.dispatchEvent(new InputEvent("beforeinput", {
        bubbles: true,
        cancelable: true,
        inputType: "insertText",
        data: text
      }));
    } catch {
      element.dispatchEvent(new Event("beforeinput", { bubbles: true, cancelable: true }));
    }

    try {
      element.dispatchEvent(new InputEvent("input", { bubbles: true, inputType: "insertText", data: text }));
    } catch {
      element.dispatchEvent(new Event("input", { bubbles: true }));
    }

    element.dispatchEvent(new Event("change", { bubbles: true }));
  }

  function logTransferDebug(message) {
    console.debug("[Context Generator Transfer]", message);
  }

  function waitForEditorText(element, text, timeoutMs) {
    const startedAt = Date.now();

    return new Promise((resolve) => {
      const tick = () => {
        if (editorContainsText(element, text)) {
          resolve(true);
          return;
        }

        if (Date.now() - startedAt > timeoutMs) {
          resolve(false);
          return;
        }

        setTimeout(tick, 100);
      };

      tick();
    });
  }

  function editorContainsText(element, text) {
    const samples = getVerificationSamples(text);
    const actual = normalizeVerificationText(getElementText(element));
    return samples.some((sample) => actual.includes(sample));
  }

  function getVerificationSamples(text) {
    const expected = normalizeVerificationText(text);
    const samples = [
      expected.slice(0, Math.min(24, expected.length)),
      expected.replace(/^[^a-z0-9]+/i, "").slice(0, 24)
    ];

    ["CONTEXT CARRY", "WHO I AM", "WHAT WE WERE DOING"].forEach((anchor) => {
      if (expected.includes(anchor)) samples.push(anchor);
    });

    return [...new Set(samples.filter((sample) => sample && sample.length >= 8))];
  }

  function normalizeVerificationText(text) {
    return String(text || "").replace(/\s+/g, " ").trim();
  }

  function getCleanVisibleText(element) {
    if (!element) return "";
    const clone = element.cloneNode(true);
    clone.querySelectorAll?.([
      `#${BUBBLE_ID}`,
      `#${OVERLAY_ID}`,
      `#${ONBOARDING_ID}`,
      `#${ONBOARDING_STYLE_ID}`,
      `#${CLAUDE_LIMIT_NUDGE_ID}`,
      `#${DESTINATION_SHEET_ID}`,
      "#context-generator-styles",
      "#context-generator-error-overlay",
      "#context-generator-fallback-modal",
      "[data-context-generator-owned='true']"
    ].join(",")).forEach((node) => node.remove());

    return cleanText(clone.innerText || clone.textContent || "");
  }

  function scrapeConversationText() {
    const messageTurns = getConversationTurns().filter((turn) => isDetectedConversationMessage(turn));
    return createConversationCaptureFromMessageTurns(messageTurns);
  }

  async function scrapeConversationTextForTransfer() {
    const initialCapture = scrapeConversationText();
    if (!shouldSweepVirtualConversation()) return initialCapture;
    return scrapeVirtualConversation(initialCapture);
  }

  function createConversationCaptureFromMessageTurns(messageTurns, metrics = {}) {
    if (messageTurns.length === 0) {
      throw new Error(NO_CONVERSATION_ERROR_MESSAGE);
    }

    const turns = messageTurns.filter((turn) => isUsefulConversationTurn(turn));
    const baseMetrics = {
      ...metrics,
      messageTurnCount: messageTurns.length,
      usefulTurnCount: turns.length,
      rawCandidateChars: messageTurns.reduce((total, turn) => total + turn.text.length, 0)
    };
    const transcript = turns
      .map((turn) => `${turn.role}: ${turn.text}`)
      .join("\n\n")
      .trim();

    if (transcript && isUsefulConversationTranscript(turns)) {
      return createConversationCapture(`${currentPlatform.name} conversation:\n\n${transcript}`, {
        ...baseMetrics,
        method: baseMetrics.method || "structured",
        transcriptChars: transcript.length
      });
    }

    const fallbackText = hasFallbackConversationEvidence(turns) ? scrapeMainConversationText(turns) : "";
    if (isUsefulFallbackConversationText(fallbackText)) {
      return createConversationCapture(`${currentPlatform.name} conversation:\n\n${fallbackText}`, {
        ...baseMetrics,
        method: baseMetrics.method || "fallback",
        transcriptChars: fallbackText.length
      });
    }

    const detectedTranscript = messageTurns
      .map((turn) => `${turn.role}: ${turn.text}`)
      .join("\n\n")
      .trim();
    if (detectedTranscript) {
      return createConversationCapture(`${currentPlatform.name} conversation:\n\n${detectedTranscript}`, {
        ...baseMetrics,
        method: baseMetrics.method || "detected",
        usefulTurnCount: messageTurns.length,
        transcriptChars: detectedTranscript.length
      });
    }

    throw new Error("Chat messages were found, but their text could not be captured yet. Try again in a moment.");
  }

  function shouldSweepVirtualConversation() {
    return (
      VIRTUAL_SWEEP_PLATFORM_IDS.has(currentPlatform.id) &&
      Number(lastConversationCaptureMetrics?.messageTurnCount || 0) >= VIRTUAL_SWEEP_MIN_TURNS
    );
  }

  async function scrapeVirtualConversation(initialCapture) {
    const initialMetrics = lastConversationCaptureMetrics || {};
    const collectedTurns = new Map();
    let scrolls = 0;
    let staleScrolls = 0;

    while (true) {
      const expandedCount = await expandCollapsedConversationContent();
      if (expandedCount > 0) {
        await waitForConversationWindowToSettle(Math.min(600, VIRTUAL_SWEEP_SETTLE_MS));
      }

      const added = collectRenderedConversationTurns(collectedTurns);
      if (scrolls >= VIRTUAL_SWEEP_MAX_SCROLLS) break;

      const beforeWindowSignature = getRenderedConversationWindowSignature();
      let afterWindowSignature = beforeWindowSignature;
      let triedBoundaryAdvance = false;

      if (shouldPreferBoundarySweepAdvance()) {
        triedBoundaryAdvance = scrollRenderedConversationBoundaryIntoView();
        if (triedBoundaryAdvance) {
          afterWindowSignature = await waitForRenderedConversationWindowChange(
            beforeWindowSignature,
            VIRTUAL_SWEEP_ANCHOR_CHANGE_TIMEOUT_MS
          );
        }
      }

      if (afterWindowSignature === beforeWindowSignature) {
        const step = Math.round(getSourceViewportHeight() * getVirtualSweepStepRatio());
        scrollSourceConversationByInstantly(step);
        afterWindowSignature = await waitForRenderedConversationWindowChange(
          beforeWindowSignature,
          VIRTUAL_SWEEP_FAST_CHANGE_TIMEOUT_MS
        );
      }

      scrolls += 1;

      if (
        afterWindowSignature === beforeWindowSignature &&
        (triedBoundaryAdvance || scrollRenderedConversationBoundaryIntoView())
      ) {
        afterWindowSignature = await waitForRenderedConversationWindowChange(
          beforeWindowSignature,
          getVirtualSweepSlowChangeTimeout()
        );
      }

      const windowChanged = afterWindowSignature !== beforeWindowSignature;
      if (!windowChanged && added === 0) {
        staleScrolls += 1;
        if (staleScrolls >= getVirtualSweepStaleScrollLimit()) break;
      } else {
        staleScrolls = 0;
      }
    }

    const sweptTurns = Array.from(collectedTurns.values());
    if (sweptTurns.length <= Number(initialMetrics.messageTurnCount || 0)) {
      return initialCapture;
    }

    return createConversationCaptureFromMessageTurns(sweptTurns, {
      method: "sweep",
      sweepScrolls: scrolls,
      sweepTurnCount: sweptTurns.length,
      initialRenderedTurnCount: initialMetrics.messageTurnCount || null,
      initialRawCandidateChars: initialMetrics.rawCandidateChars || null
    });
  }

  function collectRenderedConversationTurns(collectedTurns) {
    let added = 0;
    getConversationTurns()
      .filter((turn) => isDetectedConversationMessage(turn))
      .forEach((turn) => {
        const normalizedText = cleanText(turn.text);
        const signature = getConversationTurnSignature(turn.role, normalizedText);
        if (collectedTurns.has(signature)) return;
        collectedTurns.set(signature, { role: turn.role, text: normalizedText });
        added += 1;
      });
    return added;
  }

  function getVirtualSweepStepRatio() {
    return VIRTUAL_SWEEP_STEP_RATIO;
  }

  function shouldPreferBoundarySweepAdvance() {
    return currentPlatform.id === "claude";
  }

  function getVirtualSweepStaleScrollLimit() {
    return currentPlatform.id === "claude" ? CLAUDE_VIRTUAL_SWEEP_STALE_SCROLLS : VIRTUAL_SWEEP_STALE_SCROLLS;
  }

  function getVirtualSweepSlowChangeTimeout() {
    return currentPlatform.id === "claude"
      ? CLAUDE_VIRTUAL_SWEEP_SLOW_CHANGE_TIMEOUT_MS
      : VIRTUAL_SWEEP_SLOW_CHANGE_TIMEOUT_MS;
  }

  async function waitForRenderedConversationWindowChange(previousSignature, timeoutMs) {
    const startedAt = Date.now();
    let nextSignature = getRenderedConversationWindowSignature();
    if (nextSignature !== previousSignature) return nextSignature;

    while (Date.now() - startedAt < timeoutMs) {
      const remainingMs = timeoutMs - (Date.now() - startedAt);
      await delay(Math.min(VIRTUAL_SWEEP_CHANGE_POLL_MS, Math.max(0, remainingMs)));
      nextSignature = getRenderedConversationWindowSignature();
      if (nextSignature !== previousSignature) return nextSignature;
    }

    return nextSignature;
  }

  function scrollRenderedConversationBoundaryIntoView() {
    const turns = getConversationTurns().filter((turn) => isDetectedConversationMessage(turn));
    const anchor = turns[turns.length - 1]?.element;
    if (!anchor?.scrollIntoView) return false;

    try {
      anchor.scrollIntoView({ block: "start", inline: "nearest", behavior: "instant" });
    } catch {
      try {
        anchor.scrollIntoView(false);
      } catch {
        return false;
      }
    }
    return true;
  }

  function getRenderedConversationWindowSignature() {
    return getConversationTurns()
      .filter((turn) => isDetectedConversationMessage(turn))
      .map((turn) => getConversationTurnSignature(turn.role, cleanText(turn.text)))
      .join("\u0002");
  }

  function getConversationTurnSignature(role, text) {
    return `${role || "Message"}\u0001${text || ""}`;
  }

  function createConversationCapture(text, metrics = {}) {
    const cleaned = cleanText(text);
    const limited = limitConversationText(cleaned);
    lastConversationCaptureMetrics = {
      ...metrics,
      cleanedChars: cleaned.length,
      sentChars: limited.length,
      capped: cleaned.length > MAX_BACKEND_CONVERSATION_CHARS,
      capChars: MAX_BACKEND_CONVERSATION_CHARS
    };
    return limited;
  }

  function getConversationCaptureMetrics(conversationText) {
    if (lastConversationCaptureMetrics?.sentChars === conversationText.length) {
      return lastConversationCaptureMetrics;
    }

    return {
      method: "unknown",
      messageTurnCount: null,
      usefulTurnCount: null,
      rawCandidateChars: null,
      transcriptChars: null,
      cleanedChars: conversationText.length,
      sentChars: conversationText.length,
      capped: conversationText.length >= MAX_BACKEND_CONVERSATION_CHARS,
      capChars: MAX_BACKEND_CONVERSATION_CHARS
    };
  }

  async function scrapeConversationTextWhenReady(timeoutMs = getConversationScrapeRetryTimeout()) {
    const startedAt = Date.now();
    let lastEmptyError = null;

    while (Date.now() - startedAt <= timeoutMs) {
      try {
        return await scrapeConversationTextForTransfer();
      } catch (error) {
        if (!isNoConversationError(error)) throw error;
        lastEmptyError = error;
      }

      const remainingMs = timeoutMs - (Date.now() - startedAt);
      if (remainingMs <= 0) break;
      await waitForConversationContentSignal(Math.min(CONVERSATION_SCRAPE_RETRY_INTERVAL_MS, remainingMs));
    }

    throw lastEmptyError || new Error(NO_CONVERSATION_ERROR_MESSAGE);
  }

  function isNoConversationError(error) {
    return error?.message === NO_CONVERSATION_ERROR_MESSAGE;
  }

  function getConversationScrapeRetryTimeout() {
    return currentPlatform.id === "claude"
      ? CLAUDE_CONVERSATION_SCRAPE_RETRY_TIMEOUT_MS
      : CONVERSATION_SCRAPE_RETRY_TIMEOUT_MS;
  }

  function waitForConversationContentSignal(timeoutMs) {
    const root = document.body || document.documentElement;
    if (!root || typeof MutationObserver === "undefined") return delay(timeoutMs);

    return new Promise((resolve) => {
      let observer = null;
      let timer = null;
      let settled = false;
      const finish = () => {
        if (settled) return;
        settled = true;
        if (timer) clearTimeout(timer);
        observer?.disconnect();
        resolve();
      };

      timer = setTimeout(finish, timeoutMs);
      observer = new MutationObserver((mutations) => {
        if (mutations.every(isOwnDomMutation)) return;
        if (mutations.some(hasConversationMutationSignal)) finish();
      });
      observer.observe(root, { childList: true, subtree: true, characterData: true });
    });
  }

  function hasConversationMutationSignal(mutation) {
    if (mutation.type === "characterData") {
      return isPotentialConversationNode(mutation.target?.parentElement);
    }

    return [mutation.target, ...mutation.addedNodes]
      .some((node) => isPotentialConversationNode(node));
  }

  function isPotentialConversationNode(node) {
    if (!(node instanceof Element) || isContextGeneratorNode(node)) return false;
    const selectors = getConversationReadinessSelectors();
    return Boolean(node.matches?.(selectors) || node.closest?.(selectors));
  }

  function getConversationReadinessSelectors() {
    return [
      ...currentPlatform.conversationSelectors,
      ...GENERIC_CONVERSATION_SELECTORS,
      ...FALLBACK_CONVERSATION_ROOT_SELECTORS
    ].join(",");
  }

  function getConversationTurns() {
    const selectors = [...currentPlatform.conversationSelectors, ...GENERIC_CONVERSATION_SELECTORS];
    const candidates = [];

    document.querySelectorAll([...new Set(selectors)].join(",")).forEach((element) => {
      if (!isConversationCandidateElement(element)) return;

      const text = getCleanVisibleText(element);
      if (!text || text.length < 2) return;

      candidates.push({
        element,
        role: getConversationRole(element),
        text
      });
    });

    const messageCandidates = candidates.filter((candidate) => !isBroadConversationWrapperCandidate(candidate, candidates));

    messageCandidates.sort((a, b) => {
      if (a.element === b.element) return 0;
      return a.element.compareDocumentPosition(b.element) & Node.DOCUMENT_POSITION_PRECEDING ? 1 : -1;
    });

    let turns = [];
    messageCandidates.forEach((candidate) => {
      const sameTextTurn = turns.find((turn) => turn.text === candidate.text);
      if (sameTextTurn) {
        if (!isConversationCandidatePreferred(candidate, sameTextTurn, messageCandidates)) return;
        turns = turns.filter((turn) => turn !== sameTextTurn);
      }

      const containingTurn = turns.find((turn) => turn.element !== candidate.element && turn.element.contains(candidate.element));
      if (containingTurn) {
        if (!isConversationCandidatePreferred(candidate, containingTurn, messageCandidates)) {
          return;
        }
        turns = turns.filter((turn) => turn !== containingTurn);
      }

      const containedTurns = turns.filter((turn) => candidate.element !== turn.element && candidate.element.contains(turn.element));
      if (containedTurns.length && shouldKeepContainedConversationTurns(candidate, containedTurns, messageCandidates)) {
        return;
      }

      turns = turns.filter((turn) => !candidate.element.contains(turn.element));
      turns.push(candidate);
    });

    return turns.map(({ element, role, text }) => ({ element, role, text }));
  }

  function isBroadConversationWrapperCandidate(candidate, candidates) {
    const nestedCandidates = getNestedConversationCandidates(candidate, candidates);
    if (nestedCandidates.length < 2) return false;

    const explicitNestedCandidates = nestedCandidates.filter(hasExplicitConversationRole);
    const explicitNestedCount = explicitNestedCandidates.length;
    const nestedRoles = new Set(explicitNestedCandidates.map((nested) => nested.role));
    const candidateHasExplicitRole = hasExplicitConversationRole(candidate);
    const containsMixedNestedRoles = nestedRoles.size > 1;
    const containsDifferentNestedRole = candidateHasExplicitRole && nestedRoles.size > 0 && !nestedRoles.has(candidate.role);
    const nestedChars = nestedCandidates.reduce((total, nested) => total + nested.text.length, 0);
    const nestedCoverage = candidate.text.length ? nestedChars / candidate.text.length : 0;

    if (
      explicitNestedCount >= 2 &&
      (!candidateHasExplicitRole || containsMixedNestedRoles || containsDifferentNestedRole)
    ) {
      return true;
    }

    if (candidateHasExplicitRole && explicitNestedCount >= 6 && nestedCoverage >= 0.75) {
      return true;
    }

    return isGenericConversationContainer(candidate.element) && nestedCoverage >= 0.45;
  }

  function getNestedConversationCandidates(candidate, candidates) {
    const seenTexts = new Set();
    return candidates.filter((other) => {
      if (other.element === candidate.element || !candidate.element.contains(other.element)) return false;
      if (!other.text || other.text.length < 3 || other.text === candidate.text) return false;
      if (seenTexts.has(other.text)) return false;
      seenTexts.add(other.text);
      return true;
    });
  }

  function isGenericConversationContainer(element) {
    const label = getElementLabel(element);
    return /\b(?:main|conversation|conversations|thread|threads|chat|chats|messages|message-list|list|feed|transcript|scroll)\b/.test(label);
  }

  function shouldKeepContainedConversationTurns(candidate, containedTurns, candidates) {
    if (isBroadConversationWrapperCandidate(candidate, candidates)) return true;
    if (!hasExplicitConversationRole(candidate) && containedTurns.some(hasExplicitConversationRole)) return true;
    if (!hasExplicitConversationRole(candidate) && containedTurns.length >= 2) return true;
    return false;
  }

  function isConversationCandidatePreferred(candidate, existing, candidates) {
    if (isBroadConversationWrapperCandidate(existing, candidates) && !isBroadConversationWrapperCandidate(candidate, candidates)) {
      return true;
    }

    const candidateScore = getConversationCandidateScore(candidate, candidates);
    const existingScore = getConversationCandidateScore(existing, candidates);
    return candidateScore > existingScore;
  }

  function getConversationCandidateScore(candidate, candidates) {
    let score = 0;
    if (hasExplicitConversationRole(candidate)) score += 40;
    if (!isGenericConversationContainer(candidate.element)) score += 12;
    if (isBroadConversationWrapperCandidate(candidate, candidates)) score -= 35;
    score -= Math.min(20, getNestedConversationCandidates(candidate, candidates).length * 4);
    return score;
  }

  function getConversationRole(element) {
    const label = getElementLabel(element);
    if (/\b(user|human|you|me|query)\b/.test(label)) return "User";
    if (/\b(assistant|model|response|claude|chatgpt|gemini|grok|deepseek|bot)\b/.test(label)) {
      return currentPlatform.name;
    }
    return "Message";
  }

  function isUsefulConversationTranscript(turns) {
    if (!turns.length) return false;
    if (turns.some(hasExplicitConversationRole)) return true;
    if (turns.length < 2) return false;

    return !isEmptyConversationText(turns.map((turn) => turn.text).join("\n\n"));
  }

  function hasFallbackConversationEvidence(turns) {
    return turns.some(hasExplicitConversationRole);
  }

  function hasExplicitConversationRole(turn) {
    return turn?.role === "User" || turn?.role === currentPlatform.name;
  }

  function isUsefulConversationTurn(turn) {
    if (!turn?.text) return false;

    const text = cleanText(turn.text);
    if (text.length < 3) return false;
    if (hasExplicitConversationRole(turn)) return true;
    return !isEmptyConversationText(text);
  }

  function isDetectedConversationMessage(turn) {
    if (!turn?.text) return false;

    const text = cleanText(turn.text);
    if (text.length < 3) return false;
    return hasExplicitConversationRole(turn) || !isEmptyConversationText(text);
  }

  function scrapeMainConversationText(turns = getConversationTurns()) {
    const roots = FALLBACK_CONVERSATION_ROOT_SELECTORS
      .flatMap((selector) => Array.from(document.querySelectorAll(selector)))
      .filter((element, index, all) => all.indexOf(element) === index && isVisible(element) && !isContextGeneratorNode(element));

    const rootText = roots
      .map((element) => getCleanVisibleText(element))
      .find((text) => isUsefulFallbackConversationText(text));

    if (rootText) return rootText;

    const combinedText = turns
      .map((turn) => turn.text)
      .join("\n\n");

    return isUsefulFallbackConversationText(combinedText) ? combinedText : "";
  }

  function isUsefulFallbackConversationText(text) {
    const cleaned = cleanText(text);
    if (cleaned.length < MIN_FALLBACK_CONVERSATION_CHARS) return false;
    if (isEmptyConversationText(cleaned)) return false;

    const words = cleaned.split(/\s+/).filter(Boolean);
    return words.length >= 18;
  }

  function isEmptyConversationText(text) {
    const cleaned = cleanText(text).toLowerCase();
    if (!cleaned) return true;

    return EMPTY_START_SCREEN_TEXTS.some((emptyText) => cleaned.includes(emptyText) && cleaned.length < 900);
  }

  function isConversationCandidateElement(element) {
    if (!element || isContextGeneratorNode(element) || !isVisible(element)) return false;
    if (element.matches("input, textarea, button, select, [role='button'], [contenteditable='true']")) return false;
    if (element.closest("nav, header, footer, aside, menu")) return false;
    if (isLikelyPromptSuggestionElement(element)) return false;
    return true;
  }

  function isLikelyPromptSuggestionElement(element) {
    return Boolean(element.closest?.([
      "[aria-label*='suggest' i]",
      "[data-testid*='suggest' i]",
      "[data-test-id*='suggest' i]",
      "[class*='suggest' i]",
      "[data-testid*='starter' i]",
      "[data-test-id*='starter' i]",
      "[class*='starter' i]",
      "[data-testid*='example' i]",
      "[data-test-id*='example' i]",
      "[class*='example' i]"
    ].join(",")));
  }

  function limitConversationText(text) {
    const cleaned = cleanText(text);
    if (cleaned.length <= MAX_BACKEND_CONVERSATION_CHARS) {
      return cleaned;
    }

    const separatorLength = 4;
    const headLength = BACKEND_CONVERSATION_HEAD_CHARS;
    const tailLength = Math.max(
      0,
      MAX_BACKEND_CONVERSATION_CHARS - headLength - BACKEND_CONVERSATION_OMISSION_MARKER.length - separatorLength
    );
    return [
      cleaned.slice(0, headLength),
      BACKEND_CONVERSATION_OMISSION_MARKER,
      cleaned.slice(-tailLength)
    ].join("\n\n");
  }

  function ensureFloatingButton() {
    const input = findPlatformInput();
    const existingBubble = document.getElementById(BUBBLE_ID);

    if (!input) {
      if (existingBubble) existingBubble.style.display = "none";
      hideOnboardingNudge();
      hideClaudeLimitNudge();
      hideDestinationSheet();
      releaseBubbleSlot();
      releaseComposerSurface();
      return existingBubble;
    }

    const bubble = existingBubble || createFloatingButton();
    if (currentPlatform.id === "chatgpt") {
      releaseBubbleSlot();
      releaseComposerSurface();
      const floatingRoot = getFloatingButtonRoot();
      if (bubble.parentElement !== floatingRoot) {
        floatingRoot.appendChild(bubble);
      }
      ensureFloatingOverlay();
      updateFloatingButtonPosition();
      return bubble;
    }

    const composerSurface = findComposerSurfaceElement(input);
    if (!composerSurface) {
      bubble.style.display = "none";
      hideOnboardingNudge();
      return bubble;
    }

    reserveComposerSurface(composerSurface);

    if (currentPlatform.id !== "chatgpt" && bubble.parentElement !== composerSurface) {
      composerSurface.appendChild(bubble);
    }

    ensureFloatingOverlay();
    updateFloatingButtonPosition();
    return bubble;
  }

  function createFloatingButton() {
    const bubble = document.createElement("button");
    bubble.id = BUBBLE_ID;
    bubble.type = "button";
    bubble.title = DESTINATION_TITLE_TEXT;
    bubble.setAttribute("aria-label", DESTINATION_TITLE_TEXT);
    bubble.dataset.contextGeneratorOwned = "true";
    bubble.style.cssText = [
      "display:none",
      "position:absolute",
      "z-index:2147483647",
      `width:${BUBBLE_SIZE}px`,
      `height:${BUBBLE_SIZE}px`,
      `min-width:${BUBBLE_SIZE}px`,
      `min-height:${BUBBLE_SIZE}px`,
      `max-width:${BUBBLE_SIZE}px`,
      `max-height:${BUBBLE_SIZE}px`,
      "border-radius:9999px",
      "background:transparent",
      "border:0",
      "box-shadow:none",
      "box-sizing:border-box",
      "cursor:pointer",
      "padding:0",
      "margin:0",
      "line-height:0",
      "align-items:center",
      "justify-content:center",
      "overflow:hidden",
      "contain:layout style paint",
      "transition:filter 0.15s ease",
      "pointer-events:auto"
    ].join(";");

    const icon = document.createElement("img");
    icon.src = BUBBLE_ICON_URL;
    icon.alt = "";
    icon.style.width = "38px";
    icon.style.height = "38px";
    icon.style.objectFit = "contain";
    icon.style.display = "block";
    icon.style.pointerEvents = "none";
    icon.draggable = false;
    bubble.appendChild(icon);

    bubble.addEventListener("mouseenter", () => {
      bubble.style.filter = "brightness(1.12) drop-shadow(0 2px 6px rgba(0,0,0,0.25))";
    });
    bubble.addEventListener("mouseleave", () => {
      bubble.style.filter = "none";
    });
    bubble.addEventListener("click", (event) => {
      event.preventDefault();
      event.stopPropagation();
      if (isRunning) return;
      dismissOnboardingNudge();
      dismissClaudeLimitNudge();
      toggleDestinationSheet();
    });

    return bubble;
  }

  function ensureOnboardingStyles() {
    if (document.getElementById(ONBOARDING_STYLE_ID)) return;

    const style = document.createElement("style");
    style.id = ONBOARDING_STYLE_ID;
    style.dataset.contextGeneratorOwned = "true";
    style.textContent = `
      @keyframes contextGeneratorOnboardingIn {
        from {
          opacity: 0;
          transform: translate3d(0, 6px, 0) scale(0.98);
        }
        to {
          opacity: 1;
          transform: translate3d(0, 0, 0) scale(1);
        }
      }

      #${ONBOARDING_ID} {
        position: fixed;
        z-index: 2147483646;
        width: min(286px, calc(100vw - 28px));
        box-sizing: border-box;
        display: none;
        align-items: center;
        gap: 9px;
        min-height: 106px;
        padding: 10px 38px 10px 11px;
        border-radius: 18px;
        border: 1px solid rgba(255,255,255,0.13);
        background: linear-gradient(145deg, #101010 0%, #15151d 62%, #080808 100%);
        color: #ffffff;
        box-shadow: 0 18px 42px rgba(0,0,0,0.36), inset 0 1px 0 rgba(255,255,255,0.08);
        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
        animation: contextGeneratorOnboardingIn 0.22s cubic-bezier(0.16, 1, 0.3, 1) both;
      }

      @keyframes contextGeneratorPuppetFloat {
        0%, 100% {
          transform: translate3d(0, 0, 0) rotate(-1deg);
        }
        50% {
          transform: translate3d(0, -3px, 0) rotate(1deg);
        }
      }

      @keyframes contextGeneratorPuppetPoint {
        0%, 100% {
          transform: rotate(-12deg) translate3d(0, 0, 0);
        }
        50% {
          transform: rotate(-5deg) translate3d(5px, -1px, 0);
        }
      }

      @keyframes contextGeneratorPuppetWave {
        0%, 100% {
          transform: rotate(28deg);
        }
        50% {
          transform: rotate(34deg);
        }
      }

      @keyframes contextGeneratorPuppetBlink {
        0%, 88%, 92%, 100% {
          transform: scaleY(1);
        }
        90% {
          transform: scaleY(0.18);
        }
      }

      .context-generator-onboarding-puppet-wrap {
        position: relative;
        width: 82px;
        height: 96px;
        flex: 0 0 auto;
        transform-origin: 50% 82%;
      }

      #${ONBOARDING_ID}[data-context-generator-point="right"] .context-generator-onboarding-puppet-wrap {
        order: 2;
        margin-left: 2px;
      }

      #${ONBOARDING_ID}[data-context-generator-point="left"] .context-generator-onboarding-puppet-wrap {
        order: 0;
        margin-right: 2px;
        transform: scaleX(-1);
      }

      .context-generator-puppet {
        position: absolute;
        left: 3px;
        top: 1px;
        width: 78px;
        height: 92px;
        filter: drop-shadow(0 8px 12px rgba(0,0,0,0.22));
        animation: contextGeneratorPuppetFloat 2.15s ease-in-out infinite;
      }

      .context-generator-puppet-shadow {
        position: absolute;
        left: 16px;
        bottom: 0;
        width: 48px;
        height: 8px;
        border-radius: 999px;
        background: rgba(0,0,0,0.24);
        filter: blur(2px);
      }

      .context-generator-puppet-body {
        position: absolute;
        left: 25px;
        top: 44px;
        width: 31px;
        height: 34px;
        border-radius: 15px 15px 13px 13px;
        background: linear-gradient(145deg, #343640 0%, #191a20 68%, #0b0c11 100%);
        box-shadow: inset 0 1px 0 rgba(255,255,255,0.28), inset -6px -10px 14px rgba(0,0,0,0.26), 0 8px 16px rgba(0,0,0,0.2);
      }

      .context-generator-puppet-body::after {
        content: "";
        position: absolute;
        left: 13px;
        top: 5px;
        width: 6px;
        height: 21px;
        border-radius: 999px;
        background: linear-gradient(180deg, #7ff5d5, #26baa1);
        box-shadow: 0 0 10px rgba(75,240,203,0.18);
      }

      .context-generator-puppet-neck {
        position: absolute;
        left: 35px;
        top: 37px;
        width: 11px;
        height: 11px;
        border-radius: 0 0 8px 8px;
        background: linear-gradient(180deg, #f7c9aa, #e7a77f);
      }

      .context-generator-puppet-head {
        position: absolute;
        left: 18px;
        top: 7px;
        width: 44px;
        height: 38px;
        border-radius: 48% 52% 44% 46%;
        background: radial-gradient(circle at 32% 24%, rgba(255,255,255,0.78), transparent 16%), linear-gradient(145deg, #ffe2c9 0%, #f3b98f 100%);
        box-shadow: inset -6px -8px 12px rgba(147,78,47,0.14), inset 1px 1px 0 rgba(255,255,255,0.44), 0 6px 12px rgba(0,0,0,0.2);
      }

      .context-generator-puppet-hair {
        position: absolute;
        left: 2px;
        top: -5px;
        width: 39px;
        height: 18px;
        border-radius: 999px 999px 12px 10px;
        background: linear-gradient(145deg, #50525d 0%, #202128 48%, #0d0e13 100%);
        box-shadow: inset 6px 4px 7px rgba(255,255,255,0.08), inset -5px -5px 8px rgba(0,0,0,0.32);
        transform: rotate(-5deg);
      }

      .context-generator-puppet-hair::after {
        content: "";
        position: absolute;
        right: -4px;
        top: 8px;
        width: 13px;
        height: 15px;
        border-radius: 999px 999px 8px 999px;
        background: linear-gradient(145deg, #25262d, #0f1015);
        transform: rotate(18deg);
      }

      .context-generator-puppet-strand {
        position: absolute;
        top: 9px;
        width: 12px;
        height: 16px;
        border-radius: 999px 999px 4px 999px;
        background: linear-gradient(145deg, #383a43, #101116);
        transform-origin: 50% 0;
      }

      .context-generator-puppet-strand-one {
        left: 6px;
        transform: rotate(16deg);
      }

      .context-generator-puppet-strand-two {
        left: 18px;
        top: 8px;
        height: 15px;
        transform: rotate(-4deg);
      }

      .context-generator-puppet-strand-three {
        left: 29px;
        top: 9px;
        height: 13px;
        transform: rotate(-22deg);
      }

      .context-generator-puppet-eye {
        position: absolute;
        top: 18px;
        width: 5px;
        height: 6px;
        border-radius: 999px;
        background: radial-gradient(circle at 35% 28%, #ffffff 0 1.2px, #17171d 1.6px);
        transform-origin: 50% 50%;
        box-shadow: 0 1px 0 rgba(255,255,255,0.16);
        animation: contextGeneratorPuppetBlink 5.2s ease-in-out infinite;
      }

      .context-generator-puppet-eye-left {
        left: 13px;
      }

      .context-generator-puppet-eye-right {
        left: 27px;
      }

      .context-generator-puppet-brow {
        position: absolute;
        top: 14px;
        width: 9px;
        height: 2px;
        border-radius: 999px;
        background: rgba(31,26,25,0.54);
      }

      .context-generator-puppet-brow-left {
        left: 11px;
        transform: rotate(-9deg);
      }

      .context-generator-puppet-brow-right {
        left: 25px;
        transform: rotate(7deg);
      }

      .context-generator-puppet-cheek {
        position: absolute;
        top: 25px;
        width: 8px;
        height: 4px;
        border-radius: 999px;
        background: rgba(255,110,128,0.22);
      }

      .context-generator-puppet-cheek-left {
        left: 7px;
      }

      .context-generator-puppet-cheek-right {
        right: 7px;
      }

      .context-generator-puppet-smile {
        position: absolute;
        left: 16px;
        top: 27px;
        width: 12px;
        height: 6px;
        border-bottom: 2px solid rgba(23,23,29,0.72);
        border-radius: 0 0 999px 999px;
      }

      .context-generator-puppet-arm {
        position: absolute;
        height: 8px;
        border-radius: 999px;
        background: linear-gradient(90deg, #f0b58b, #ffe2c7 62%, #fff3e2);
        box-shadow: inset 0 1px 0 rgba(255,255,255,0.44), 0 3px 7px rgba(0,0,0,0.16);
      }

      .context-generator-puppet-arm-back {
        left: 9px;
        top: 57px;
        width: 29px;
        transform-origin: 27px 50%;
        transform: rotate(28deg);
        animation: contextGeneratorPuppetWave 1.7s ease-in-out infinite;
      }

      .context-generator-puppet-arm-point {
        left: 48px;
        top: 49px;
        width: 41px;
        transform-origin: 4px 50%;
        animation: contextGeneratorPuppetPoint 0.95s ease-in-out infinite;
      }

      .context-generator-puppet-hand {
        position: absolute;
        right: -5px;
        top: -3px;
        width: 13px;
        height: 13px;
        border-radius: 999px;
        background: radial-gradient(circle at 35% 30%, #ffffff, #ffe1c5 74%);
        box-shadow: inset -2px -2px 4px rgba(176,92,54,0.1);
      }

      .context-generator-puppet-finger {
        position: absolute;
        right: -13px;
        top: 3px;
        width: 18px;
        height: 5px;
        border-radius: 999px;
        background: linear-gradient(90deg, #ffe1c5, #fff4e7);
        box-shadow: 4px 0 9px rgba(255,255,255,0.18);
      }

      .context-generator-puppet-rest-hand {
        position: absolute;
        left: -5px;
        top: -3px;
        width: 12px;
        height: 12px;
        border-radius: 999px;
        background: radial-gradient(circle at 35% 30%, #ffffff, #ffe1c5 74%);
        box-shadow: inset -2px -2px 4px rgba(176,92,54,0.1);
      }

      .context-generator-puppet-leg {
        position: absolute;
        top: 74px;
        width: 8px;
        height: 15px;
        border-radius: 999px;
        background: linear-gradient(180deg, #22242c, #0f1015);
      }

      .context-generator-puppet-leg-left {
        left: 30px;
        transform: rotate(6deg);
      }

      .context-generator-puppet-leg-right {
        left: 44px;
        transform: rotate(-6deg);
      }

      .context-generator-puppet-shoe {
        position: absolute;
        left: -5px;
        bottom: -3px;
        width: 17px;
        height: 7px;
        border-radius: 999px 999px 7px 7px;
        background: linear-gradient(180deg, #3d4049, #111217);
        box-shadow: inset 0 1px 0 rgba(255,255,255,0.16);
      }

      .context-generator-onboarding-copy {
        min-width: 0;
        flex: 1;
        order: 1;
      }

      .context-generator-onboarding-title {
        font-family: Georgia, 'Times New Roman', serif;
        font-size: 12.4px;
        font-weight: 600;
        line-height: 1.12;
        letter-spacing: 0;
        color: #ffffff;
        text-rendering: geometricPrecision;
        white-space: nowrap;
      }

      .context-generator-onboarding-body {
        margin-top: 4px;
        font-size: 11.5px;
        font-weight: 500;
        line-height: 1.35;
        letter-spacing: 0;
        color: rgba(255,255,255,0.68);
      }

      .context-generator-onboarding-dismiss {
        position: absolute;
        right: 8px;
        top: 8px;
        width: 24px;
        height: 24px;
        border-radius: 999px;
        border: 1px solid rgba(255,255,255,0.11);
        background: rgba(255,255,255,0.06);
        color: rgba(255,255,255,0.76);
        cursor: pointer;
        font: inherit;
        font-size: 12px;
        font-weight: 700;
        line-height: 22px;
        padding: 0;
      }

      .context-generator-onboarding-dismiss:hover {
        background: rgba(255,255,255,0.1);
        color: #ffffff;
      }

      @media (prefers-reduced-motion: reduce) {
        #${ONBOARDING_ID},
        .context-generator-puppet,
        .context-generator-puppet-arm,
        .context-generator-puppet-eye {
          animation: none;
        }
      }
    `;
    (document.head || document.documentElement).appendChild(style);
  }

  function createOnboardingNudge() {
    ensureOnboardingStyles();

    const nudge = document.createElement("div");
    nudge.id = ONBOARDING_ID;
    nudge.dataset.contextGeneratorOwned = "true";
    nudge.setAttribute("role", "note");
    nudge.setAttribute("aria-live", "polite");

    const puppetWrap = document.createElement("div");
    puppetWrap.className = "context-generator-onboarding-puppet-wrap";
    puppetWrap.setAttribute("aria-hidden", "true");

    const puppet = document.createElement("div");
    puppet.className = "context-generator-puppet";

    const shadow = document.createElement("span");
    shadow.className = "context-generator-puppet-shadow";
    const backArm = document.createElement("span");
    backArm.className = "context-generator-puppet-arm context-generator-puppet-arm-back";
    const restHand = document.createElement("span");
    restHand.className = "context-generator-puppet-rest-hand";
    backArm.appendChild(restHand);
    const bodyShape = document.createElement("span");
    bodyShape.className = "context-generator-puppet-body";
    const neck = document.createElement("span");
    neck.className = "context-generator-puppet-neck";

    const head = document.createElement("span");
    head.className = "context-generator-puppet-head";
    [
      "context-generator-puppet-hair",
      "context-generator-puppet-strand context-generator-puppet-strand-one",
      "context-generator-puppet-strand context-generator-puppet-strand-two",
      "context-generator-puppet-strand context-generator-puppet-strand-three",
      "context-generator-puppet-brow context-generator-puppet-brow-left",
      "context-generator-puppet-brow context-generator-puppet-brow-right",
      "context-generator-puppet-eye context-generator-puppet-eye-left",
      "context-generator-puppet-eye context-generator-puppet-eye-right",
      "context-generator-puppet-cheek context-generator-puppet-cheek-left",
      "context-generator-puppet-cheek context-generator-puppet-cheek-right",
      "context-generator-puppet-smile"
    ].forEach((className) => {
      const part = document.createElement("span");
      part.className = className;
      head.appendChild(part);
    });

    const pointArm = document.createElement("span");
    pointArm.className = "context-generator-puppet-arm context-generator-puppet-arm-point";
    const hand = document.createElement("span");
    hand.className = "context-generator-puppet-hand";
    const finger = document.createElement("span");
    finger.className = "context-generator-puppet-finger";
    pointArm.appendChild(hand);
    pointArm.appendChild(finger);

    const leftLeg = document.createElement("span");
    leftLeg.className = "context-generator-puppet-leg context-generator-puppet-leg-left";
    const leftShoe = document.createElement("span");
    leftShoe.className = "context-generator-puppet-shoe";
    leftLeg.appendChild(leftShoe);

    const rightLeg = document.createElement("span");
    rightLeg.className = "context-generator-puppet-leg context-generator-puppet-leg-right";
    const rightShoe = document.createElement("span");
    rightShoe.className = "context-generator-puppet-shoe";
    rightLeg.appendChild(rightShoe);

    puppet.appendChild(shadow);
    puppet.appendChild(backArm);
    puppet.appendChild(leftLeg);
    puppet.appendChild(rightLeg);
    puppet.appendChild(bodyShape);
    puppet.appendChild(neck);
    puppet.appendChild(head);
    puppet.appendChild(pointArm);
    puppetWrap.appendChild(puppet);

    const copy = document.createElement("div");
    copy.className = "context-generator-onboarding-copy";
    const title = document.createElement("div");
    title.className = "context-generator-onboarding-title";
    title.textContent = ONBOARDING_TITLE_TEXT;
    const body = document.createElement("div");
    body.className = "context-generator-onboarding-body";
    body.textContent = ONBOARDING_BODY_TEXT;
    copy.appendChild(title);
    copy.appendChild(body);

    const dismiss = document.createElement("button");
    dismiss.type = "button";
    dismiss.className = "context-generator-onboarding-dismiss";
    dismiss.textContent = "OK";
    dismiss.setAttribute("aria-label", "Dismiss Cap-Context tip");
    dismiss.addEventListener("click", (event) => {
      event.preventDefault();
      event.stopPropagation();
      dismissOnboardingNudge();
    });

    nudge.appendChild(puppetWrap);
    nudge.appendChild(copy);
    nudge.appendChild(dismiss);
    nudge.addEventListener("click", (event) => event.stopPropagation());
    document.body.appendChild(nudge);
    return nudge;
  }

  function maybeShowOnboardingNudge(bubble) {
    if (!bubble || isOnboardingDismissed() || isRunning || isDestinationSheetOpen()) return;
    if (bubble.style.display === "none") {
      hideOnboardingNudge();
      return;
    }

    const visibleNudge = document.getElementById(ONBOARDING_ID);
    if (visibleNudge && visibleNudge.style.display !== "none") {
      positionOnboardingNudge(visibleNudge, bubble);
      return;
    }

    if (onboardingTimer) {
      const nudge = document.getElementById(ONBOARDING_ID);
      if (nudge && nudge.style.display !== "none") positionOnboardingNudge(nudge, bubble);
      return;
    }

    onboardingTimer = window.setTimeout(() => {
      onboardingTimer = null;
      if (isOnboardingDismissed() || isRunning || isDestinationSheetOpen()) return;

      const currentBubble = document.getElementById(BUBBLE_ID);
      if (!currentBubble || currentBubble.style.display === "none") return;

      const nudge = document.getElementById(ONBOARDING_ID) || createOnboardingNudge();
      positionOnboardingNudge(nudge, currentBubble);
      nudge.style.display = "flex";
    }, ONBOARDING_SHOW_DELAY_MS);
  }

  function positionOnboardingNudge(nudge, bubble) {
    const bubbleRect = bubble.getBoundingClientRect();
    if (!bubbleRect.width || !bubbleRect.height) return;

    const margin = 12;
    const gap = 14;
    const nudgeWidth = Math.min(286, window.innerWidth - margin * 2);
    const nudgeHeight = nudge.offsetHeight || 106;
    const canSitLeft = bubbleRect.left - gap - nudgeWidth >= margin;
    const left = canSitLeft
      ? bubbleRect.left - gap - nudgeWidth
      : Math.min(window.innerWidth - nudgeWidth - margin, bubbleRect.right + gap);
    const top = Math.max(
      margin,
      Math.min(
        bubbleRect.top + bubbleRect.height / 2 - nudgeHeight / 2,
        window.innerHeight - nudgeHeight - margin
      )
    );

    nudge.dataset.contextGeneratorPoint = canSitLeft ? "right" : "left";
    nudge.style.left = `${Math.round(left)}px`;
    nudge.style.top = `${Math.round(top)}px`;
  }

  function hideOnboardingNudge() {
    if (onboardingTimer) {
      clearTimeout(onboardingTimer);
      onboardingTimer = null;
    }

    const nudge = document.getElementById(ONBOARDING_ID);
    if (nudge) nudge.style.display = "none";
  }

  function dismissOnboardingNudge() {
    onboardingDismissedThisSession = true;
    hideOnboardingNudge();

    try {
      window.localStorage?.setItem(ONBOARDING_STORAGE_KEY, "true");
    } catch (_error) {
      // Some AI pages lock storage; the session flag still prevents repeat nags.
    }
  }

  function isOnboardingDismissed() {
    if (onboardingDismissedThisSession) return true;

    try {
      return window.localStorage?.getItem(ONBOARDING_STORAGE_KEY) === "true";
    } catch (_error) {
      return false;
    }
  }

  function updateClaudeLimitNudge() {
    if (currentPlatform.id !== "claude" || isRunning || isDestinationSheetOpen()) {
      hideClaudeLimitNudge();
      return;
    }

    const bubble = document.getElementById(BUBBLE_ID);
    const claudeLimitVisible = isClaudeLimitVisible();
    if (!claudeLimitVisible) {
      claudeLimitNudgeDismissedUntilLimitClears = false;
    }

    if (
      !bubble ||
      bubble.style.display === "none" ||
      !isVisible(bubble) ||
      !claudeLimitVisible ||
      claudeLimitNudgeDismissedUntilLimitClears ||
      isClaudeComposerFocusTarget(document.activeElement)
    ) {
      if (claudeLimitVisible && isClaudeComposerFocusTarget(document.activeElement)) {
        dismissClaudeLimitNudge();
      }
      hideClaudeLimitNudge();
      return;
    }

    const nudge = document.getElementById(CLAUDE_LIMIT_NUDGE_ID) || createClaudeLimitNudge();
    const wasHidden = nudge.style.display === "none" || nudge.dataset.contextGeneratorVisible !== "true";
    nudge.style.display = "flex";
    positionClaudeLimitNudge(nudge, bubble);
    if (wasHidden) {
      nudge.dataset.contextGeneratorVisible = "true";
      nudge.style.opacity = "0";
      nudge.style.transform = nudge.dataset.contextGeneratorPoint === "right" ? "translate3d(8px,0,0)" : "translate3d(-8px,0,0)";
      requestAnimationFrame(() => {
        nudge.style.opacity = "1";
        nudge.style.transform = "translate3d(0,0,0)";
      });
    }
  }

  function createClaudeLimitNudge() {
    const nudge = document.createElement("button");
    nudge.id = CLAUDE_LIMIT_NUDGE_ID;
    nudge.type = "button";
    nudge.dataset.contextGeneratorOwned = "true";
    nudge.setAttribute("aria-label", CLAUDE_LIMIT_NUDGE_TEXT);
    nudge.style.cssText = [
      "display:none",
      "position:fixed",
      "z-index:2147483647",
      "width:min(306px,calc(100vw - 24px))",
      "box-sizing:border-box",
      "padding:13px 14px",
      "border:1px solid rgba(255,255,255,0.14)",
      "border-radius:16px",
      "background:linear-gradient(145deg,#121212 0%,#181820 58%,#0d0d12 100%)",
      "box-shadow:0 18px 42px rgba(0,0,0,0.34),inset 0 1px 0 rgba(255,255,255,0.07)",
      "color:#fff",
      "font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif",
      "font-size:13px",
      "font-weight:580",
      "line-height:1.38",
      "letter-spacing:0",
      "text-align:left",
      "cursor:pointer",
      "gap:7px",
      "flex-direction:column",
      "transition:opacity 220ms ease,transform 220ms ease",
      "overflow:visible"
    ].join(";");

    const tail = document.createElement("span");
    tail.dataset.contextGeneratorLimitTail = "true";
    tail.style.cssText = [
      "position:absolute",
      "width:12px",
      "height:12px",
      "background:#15151b",
      "border-top:1px solid rgba(255,255,255,0.14)",
      "border-right:1px solid rgba(255,255,255,0.14)",
      "transform:rotate(45deg)",
      "top:calc(50% - 6px)"
    ].join(";");

    const firstLine = document.createElement("span");
    firstLine.textContent = "Claude's brilliant. Claude's also broke by message 20.";
    firstLine.style.fontWeight = "760";

    const secondLine = document.createElement("span");
    secondLine.textContent = "We've got you covered. Tap to continue in another AI with context.";
    secondLine.style.color = "rgba(255,255,255,0.74)";

    nudge.appendChild(tail);
    nudge.appendChild(firstLine);
    nudge.appendChild(secondLine);
    nudge.addEventListener("click", (event) => {
      event.preventDefault();
      event.stopPropagation();
      dismissClaudeLimitNudge();
      if (!isDestinationSheetOpen()) toggleDestinationSheet();
    });

    document.body.appendChild(nudge);
    return nudge;
  }

  function positionClaudeLimitNudge(nudge, bubble) {
    const bubbleRect = bubble.getBoundingClientRect();
    const margin = 12;
    const gap = 12;
    const nudgeWidth = Math.min(306, window.innerWidth - margin * 2);
    const nudgeHeight = nudge.offsetHeight || 92;
    const canSitLeft = bubbleRect.left - gap - nudgeWidth >= margin;
    const left = canSitLeft
      ? bubbleRect.left - gap - nudgeWidth
      : Math.min(window.innerWidth - nudgeWidth - margin, bubbleRect.right + gap);
    const top = Math.max(margin, Math.min(bubbleRect.top + bubbleRect.height / 2 - nudgeHeight / 2, window.innerHeight - nudgeHeight - margin));
    const tail = nudge.querySelector("[data-context-generator-limit-tail='true']");

    nudge.dataset.contextGeneratorPoint = canSitLeft ? "right" : "left";
    nudge.style.left = `${Math.round(left)}px`;
    nudge.style.top = `${Math.round(top)}px`;
    if (tail) {
      tail.style.right = canSitLeft ? "-6px" : "auto";
      tail.style.left = canSitLeft ? "auto" : "-6px";
    }
  }

  function hideClaudeLimitNudge() {
    const nudge = document.getElementById(CLAUDE_LIMIT_NUDGE_ID);
    if (!nudge) return;
    nudge.dataset.contextGeneratorVisible = "false";
    nudge.style.display = "none";
  }

  function dismissClaudeLimitNudge() {
    const nudge = document.getElementById(CLAUDE_LIMIT_NUDGE_ID);
    const nudgeVisible = nudge && nudge.style.display !== "none";
    if (currentPlatform.id === "claude" && (nudgeVisible || isClaudeLimitVisible())) {
      claudeLimitNudgeDismissedUntilLimitClears = true;
    }
    hideClaudeLimitNudge();
  }

  function isClaudeLimitVisible() {
    const selectors = [
      "[role='alert']",
      "[role='status']",
      "[aria-live]",
      "[data-testid*='limit' i]",
      "[data-testid*='error' i]",
      "[class*='limit' i]",
      "[class*='error' i]",
      "[class*='toast' i]",
      "[class*='banner' i]",
      "[class*='modal' i]",
      "[class*='popover' i]"
    ].join(",");

    return Array.from(document.querySelectorAll(selectors)).some((element) => {
      if (isContextGeneratorNode(element) || !isVisible(element)) return false;
      return isClaudeLimitText(element.innerText || element.textContent || "");
    });
  }

  function isClaudeLimitText(text) {
    const normalized = cleanText(text).toLowerCase();
    if (!normalized || normalized.length > 700) return false;

    return [
      /(?:message|usage|rate|conversation).{0,36}limit/,
      /limit.{0,36}(?:reached|reset|resets|later|tomorrow|messages|usage)/,
      /(?:reached|hit).{0,36}(?:message|usage|rate)?.{0,20}limit/,
      /out of.{0,36}(?:messages|usage|prompts)/,
      /(?:try again|come back).{0,36}(?:later|tomorrow)/,
      /(?:messages|usage).{0,36}(?:reset|resets|available)/
    ].some((pattern) => pattern.test(normalized));
  }

  function isClaudeComposerFocusTarget(target) {
    if (currentPlatform.id !== "claude" || !(target instanceof Element)) return false;

    const input = findPlatformInput();
    return Boolean(
      input &&
      (target === input || input.contains(target) || target.closest?.("textarea,[contenteditable='true']") === input)
    );
  }

  function ensureDestinationSheetStyles() {
    if (document.getElementById(DESTINATION_SHEET_STYLE_ID)) return;

    const style = document.createElement("style");
    style.id = DESTINATION_SHEET_STYLE_ID;
    style.textContent = `
      @keyframes contextGeneratorTileIn {
        from {
          opacity: 0;
          transform: translate3d(0, 3px, 0) scale(0.992);
          filter: brightness(0.96);
        }
        to {
          opacity: 1;
          transform: translate3d(0, 0, 0) scale(1);
          filter: brightness(1);
        }
      }

      @keyframes contextGeneratorSpinnerSpin {
        to {
          transform: rotate(360deg);
        }
      }

      .context-generator-destination-tile.context-generator-tile-enter {
        animation: contextGeneratorTileIn 0.18s cubic-bezier(0.16, 1, 0.3, 1) both;
      }

      .context-generator-tile-aura {
        animation: none;
      }

      .context-generator-tile-spinner {
        display: none;
        width: 12px;
        height: 12px;
        border-radius: 999px;
        border: 1.5px solid rgba(245,245,245,0.18);
        border-top-color: rgba(245,245,245,0.78);
        flex: 0 0 auto;
        position: relative;
        z-index: 2;
        animation: contextGeneratorSpinnerSpin 0.7s linear infinite;
      }

      #${DESTINATION_SHEET_ID} .context-generator-destination-tile:focus-visible {
        border-color: rgba(255,255,255,0.26) !important;
        box-shadow: inset 0 1px 0 rgba(255,255,255,0.1), 0 0 0 3px rgba(255,255,255,0.09) !important;
      }

      @media (max-width: 520px) {
        #${DESTINATION_SHEET_ID} {
          width: calc(100vw - 24px) !important;
          max-height: calc(100vh - 24px) !important;
          left: 12px !important;
          right: auto !important;
          top: auto !important;
          bottom: max(12px, env(safe-area-inset-bottom)) !important;
          transform-origin: bottom center !important;
        }
      }

      @media (prefers-reduced-motion: reduce) {
        .context-generator-destination-tile.context-generator-tile-enter,
        .context-generator-tile-aura {
          animation: none;
        }

        .context-generator-tile-spinner {
          animation: none;
        }
      }
    `;
    (document.head || document.documentElement).appendChild(style);
  }

  function ensureDestinationSheet() {
    let sheet = document.getElementById(DESTINATION_SHEET_ID);
    if (sheet) return sheet;

    ensureDestinationSheetStyles();

    sheet = document.createElement("div");
    sheet.id = DESTINATION_SHEET_ID;
    sheet.dataset.contextGeneratorOwned = "true";
    sheet.style.cssText = [
      "display:none",
      "position:fixed",
      "z-index:2147483647",
      `width:${DESTINATION_SHEET_WIDTH}px`,
      "box-sizing:border-box",
      "padding:14px",
      "border-radius:20px",
      "border:1px solid rgba(255,255,255,0.14)",
      "background:linear-gradient(180deg,rgba(29,29,31,0.985) 0%,rgba(18,18,20,0.99) 52%,rgba(10,10,11,0.995) 100%)",
      "box-shadow:0 24px 64px rgba(0,0,0,0.62), 0 4px 18px rgba(0,0,0,0.44), inset 0 1px 0 rgba(255,255,255,0.09)",
      "backdrop-filter:blur(22px) saturate(1.08)",
      "color:#f5f5f5",
      "font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif",
      "overflow:hidden",
      "opacity:0",
      "transform:translate3d(0,2px,0) scale(0.996)",
      "transform-origin:bottom right",
      "will-change:transform,opacity",
      "transition:opacity 0.14s cubic-bezier(0.16,1,0.3,1), transform 0.16s cubic-bezier(0.16,1,0.3,1)"
    ].join(";");

    const header = document.createElement("div");
    header.style.cssText = "padding:2px 2px 14px;display:flex;align-items:flex-start;justify-content:space-between;gap:14px";
    const headingGroup = document.createElement("div");
    headingGroup.style.cssText = "min-width:0;display:flex;flex-direction:column;gap:5px";
    const kicker = document.createElement("div");
    kicker.textContent = "CAP CONTEXT";
    kicker.style.cssText = "font-size:9.5px;font-weight:750;line-height:1;letter-spacing:0.14em;color:rgba(255,255,255,0.46)";
    const title = document.createElement("div");
    title.textContent = DESTINATION_TITLE_TEXT;
    title.style.cssText = "font-size:18px;font-weight:690;letter-spacing:-0.025em;color:#ffffff;line-height:1.12;text-wrap:balance";
    const helper = document.createElement("div");
    helper.textContent = DESTINATION_HELPER_TEXT;
    helper.style.cssText = "font-size:11.5px;font-weight:450;line-height:1.35;color:rgba(255,255,255,0.54);white-space:nowrap;overflow:hidden;text-overflow:ellipsis";
    headingGroup.appendChild(kicker);
    headingGroup.appendChild(title);
    headingGroup.appendChild(helper);
    const badge = document.createElement("button");
    badge.type = "button";
    badge.textContent = "Cap-Context";
    badge.setAttribute("aria-label", "Open Cap-Context site");
    badge.style.cssText = [
      "height:24px",
      "padding:0 9px",
      "border-radius:999px",
      "border:1px solid transparent",
      "background:rgba(255,255,255,0.035)",
      "box-shadow:none",
      "color:rgba(255,255,255,0.68)",
      "font-size:10.5px",
      "font-weight:600",
      "line-height:24px",
      "letter-spacing:0",
      "font-family:inherit",
      "cursor:pointer",
      "outline:0",
      "transition:border-color 0.14s ease, background 0.14s ease, box-shadow 0.14s ease, color 0.14s ease"
    ].join(";");
    const setBadgeActive = () => {
      badge.style.borderColor = "rgba(255,255,255,0.24)";
      badge.style.background = "rgba(255,255,255,0.052)";
      badge.style.boxShadow = "0 0 0 1px rgba(0,0,0,0.28), 0 0 12px rgba(255,255,255,0.11), inset 0 1px 0 rgba(255,255,255,0.16)";
      badge.style.color = "rgba(255,255,255,0.74)";
    };
    const setBadgeIdle = () => {
      badge.style.borderColor = "transparent";
      badge.style.background = "rgba(255,255,255,0.035)";
      badge.style.boxShadow = "none";
      badge.style.color = "rgba(255,255,255,0.68)";
    };
    badge.addEventListener("mouseenter", setBadgeActive);
    badge.addEventListener("mouseleave", setBadgeIdle);
    badge.addEventListener("focus", setBadgeActive);
    badge.addEventListener("blur", setBadgeIdle);
    badge.addEventListener("click", (event) => {
      event.preventDefault();
      event.stopPropagation();
      window.location.assign(CAP_CONTEXT_SITE_URL);
    });
    header.appendChild(headingGroup);
    header.appendChild(badge);
    sheet.appendChild(header);

    const options = Object.entries(PLATFORMS)
      .filter(([id]) => id !== currentPlatform.id)
      .map(([id, platform]) => ({ ...platform, id }));

    const grid = document.createElement("div");
    grid.style.cssText = "display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:9px";

    options.forEach((option, index) => {
      const button = document.createElement("button");
      button.type = "button";
      button.className = "context-generator-destination-tile";
      button.dataset.contextGeneratorAccent = option.accent;
      button.dataset.contextGeneratorDetail = option.detail;
      button.style.cssText = [
        "width:100%",
        "height:66px",
        "border:1px solid rgba(255,255,255,0.11)",
        "border-radius:14px",
        "background:linear-gradient(180deg,rgba(255,255,255,0.055) 0%,rgba(255,255,255,0.022) 100%)",
        "color:#ffffff",
        "display:flex",
        "align-items:center",
        "gap:10px",
        "padding:0 12px",
        "box-sizing:border-box",
        "cursor:pointer",
        "text-align:left",
        "font:inherit",
        "outline:0",
        "position:relative",
        "overflow:hidden",
        "isolation:isolate",
        "box-shadow:inset 0 1px 0 rgba(255,255,255,0.065), 0 1px 1px rgba(0,0,0,0.32)",
        "transition:transform 0.15s cubic-bezier(0.16,1,0.3,1), border-color 0.15s ease, background 0.15s ease, box-shadow 0.15s ease"
      ].join(";");

      const aura = document.createElement("span");
      aura.className = "context-generator-tile-aura";
      aura.style.cssText = [
        "position:absolute",
        "left:10px",
        "top:12px",
        "bottom:12px",
        "width:38px",
        "z-index:0",
        "pointer-events:none",
        "border-radius:999px",
        `background:radial-gradient(ellipse at 22% 50%, ${option.accent}24 0, ${option.accent}12 36%, ${option.accent}04 61%, transparent 80%)`,
        "opacity:0.24",
        "filter:blur(8px)",
        "transform:translate3d(0,0,0) scaleX(1)",
        "transition:opacity 0.16s ease, left 0.16s ease, right 0.16s ease, width 0.16s ease, border-radius 0.16s ease, background 0.16s ease"
      ].join(";");

      const logoWrap = document.createElement("div");
      logoWrap.style.cssText = "width:34px;height:34px;display:flex;align-items:center;justify-content:center;flex:0 0 auto;opacity:0.98;position:relative;z-index:2";
      const logo = document.createElement("img");
      logo.src = getExtensionAssetUrl(option.logo);
      logo.alt = "";
      logo.draggable = false;
      logo.style.cssText = `width:${option.logoSize}px;height:${option.logoSize}px;object-fit:contain;display:block;filter:drop-shadow(0 1px 3px rgba(0,0,0,0.28))`;
      logoWrap.appendChild(logo);

      const copy = document.createElement("div");
      copy.style.cssText = "display:flex;flex-direction:column;gap:1px;min-width:0;flex:1;position:relative;z-index:2";
      const name = document.createElement("div");
      name.textContent = option.name;
      name.style.cssText = "font-size:13px;font-weight:720;line-height:1.2;color:#ffffff;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;letter-spacing:-0.01em";
      const detail = document.createElement("div");
      detail.className = "context-generator-tile-detail";
      detail.textContent = option.detail;
      detail.style.cssText = "font-size:10.5px;font-weight:500;line-height:1.3;color:rgba(255,255,255,0.5);white-space:nowrap;overflow:hidden;text-overflow:ellipsis";
      copy.appendChild(name);
      copy.appendChild(detail);

      const spinner = document.createElement("span");
      spinner.className = "context-generator-tile-spinner";
      spinner.setAttribute("aria-hidden", "true");

      const setButtonActive = () => {
        button.style.background = "linear-gradient(180deg,rgba(255,255,255,0.09) 0%,rgba(255,255,255,0.04) 100%)";
        button.style.borderColor = "rgba(255,255,255,0.19)";
        button.style.boxShadow = "inset 0 1px 0 rgba(255,255,255,0.1), 0 8px 18px rgba(0,0,0,0.24)";
        aura.style.opacity = "0.42";
        button.style.transform = "translateY(-2px)";
      };
      const setButtonIdle = () => {
        button.style.background = "linear-gradient(180deg,rgba(255,255,255,0.055) 0%,rgba(255,255,255,0.022) 100%)";
        button.style.borderColor = "rgba(255,255,255,0.11)";
        button.style.boxShadow = "inset 0 1px 0 rgba(255,255,255,0.065), 0 1px 1px rgba(0,0,0,0.32)";
        aura.style.left = "10px";
        aura.style.right = "auto";
        aura.style.width = "38px";
        aura.style.borderRadius = "999px";
        aura.style.background = `radial-gradient(ellipse at 22% 50%, ${option.accent}24 0, ${option.accent}12 36%, ${option.accent}04 61%, transparent 80%)`;
        aura.style.opacity = "0.24";
        button.style.transform = "translateY(0)";
      };

      button.appendChild(aura);
      button.appendChild(logoWrap);
      button.appendChild(copy);
      button.appendChild(spinner);
      button.addEventListener("mouseenter", setButtonActive);
      button.addEventListener("mouseleave", setButtonIdle);
      button.addEventListener("focus", setButtonActive);
      button.addEventListener("blur", setButtonIdle);
      button.addEventListener("click", (event) => {
        event.preventDefault();
        event.stopPropagation();
        if (button.dataset.contextGeneratorLoading === "true") return;
        button.dataset.contextGeneratorLoading = "true";
        button.setAttribute("aria-busy", "true");
        button.style.pointerEvents = "none";
        spinner.style.display = "block";
        detail.textContent = "Opening...";
        button.style.transform = "scale(0.985)";
        startDestinationTransfer(option.id);
      });

      grid.appendChild(button);
    });

    sheet.appendChild(grid);

    const footer = document.createElement("div");
    footer.textContent = "Pastes only · You review before sending";
    footer.style.cssText = [
      "margin:12px 2px 1px",
      "padding-top:10px",
      "padding-bottom:1px",
      "border-top:1px solid rgba(255,255,255,0.065)",
      "color:rgba(255,255,255,0.47)",
      "font-family:inherit",
      "font-size:10.5px",
      "font-weight:520",
      "line-height:1.35",
      "letter-spacing:0",
      "text-align:center",
      "white-space:nowrap",
      "overflow:hidden",
      "text-overflow:ellipsis"
    ].join(";");
    sheet.appendChild(footer);

    sheet.addEventListener("click", (event) => event.stopPropagation());
    document.body.appendChild(sheet);
    document.addEventListener("click", hideDestinationSheet);
    document.addEventListener("keydown", (event) => {
      if (event.key === "Escape") hideDestinationSheet();
    });

    return sheet;
  }

  function toggleDestinationSheet() {
    hideOnboardingNudge();
    hideClaudeLimitNudge();
    const existingSheet = document.getElementById(DESTINATION_SHEET_ID);
    if (existingSheet?.style.display === "block") {
      hideDestinationSheet();
      return;
    }

    scheduleWarmSummary();

    const sheet = ensureDestinationSheet();
    if (destinationSheetAnimationFrame) cancelAnimationFrame(destinationSheetAnimationFrame);
    sheet.style.opacity = "0";
    sheet.style.transform = "translate3d(0,2px,0) scale(0.996)";
    sheet.style.display = "block";
    delete sheet.dataset.contextGeneratorPositionLocked;
    positionDestinationSheet();
    resetDestinationTiles(sheet);
    animateDestinationTiles(sheet);
    warmDestinationConnections();
    if (window.matchMedia?.("(prefers-reduced-motion: reduce)").matches) {
      sheet.style.opacity = "1";
      sheet.style.transform = "translate3d(0,0,0) scale(1)";
      return;
    }
    destinationSheetAnimationFrame = requestAnimationFrame(() => {
      sheet.style.opacity = "1";
      sheet.style.transform = "translate3d(0,0,0) scale(1)";
      destinationSheetAnimationFrame = null;
    });
  }

  function hideDestinationSheet() {
    const sheet = document.getElementById(DESTINATION_SHEET_ID);
    if (sheet) {
      if (destinationSheetAnimationFrame) {
        cancelAnimationFrame(destinationSheetAnimationFrame);
        destinationSheetAnimationFrame = null;
      }
      sheet.style.opacity = "0";
      sheet.style.transform = "translate3d(0,2px,0) scale(0.996)";
      sheet.style.display = "none";
      delete sheet.dataset.contextGeneratorPositionLocked;
    }
  }

  function warmDestinationConnections() {
    const head = document.head || document.documentElement;
    if (!head) return;

    Object.entries(PLATFORMS)
      .filter(([id]) => id !== currentPlatform.id)
      .forEach(([id, platform]) => {
        const origin = getUrlOrigin(platform.url);
        if (!origin) return;

        const idValue = `context-generator-preconnect-${id}`;
        if (document.getElementById(idValue)) return;

        const link = document.createElement("link");
        link.id = idValue;
        link.dataset.contextGeneratorOwned = "true";
        link.rel = "preconnect";
        link.href = origin;
        link.crossOrigin = "anonymous";
        head.appendChild(link);
      });
  }

  function getUrlOrigin(url) {
    try {
      return new URL(url).origin;
    } catch {
      return "";
    }
  }

  function isDestinationSheetOpen() {
    const sheet = document.getElementById(DESTINATION_SHEET_ID);
    return Boolean(sheet && sheet.style.display === "block");
  }

  function positionDestinationSheet() {
    const sheet = document.getElementById(DESTINATION_SHEET_ID);
    const bubble = document.getElementById(BUBBLE_ID);
    if (!sheet || !bubble || sheet.style.display === "none") return;
    if (sheet.dataset.contextGeneratorPositionLocked === "true") return;

    const bubbleRect = bubble.getBoundingClientRect();
    const margin = 10;
    const sheetHeight = sheet.offsetHeight || 164;
    const left = Math.max(
      margin,
      Math.min(
        bubbleRect.right - DESTINATION_SHEET_WIDTH,
        window.innerWidth - DESTINATION_SHEET_WIDTH - margin
      )
    );
    const preferredTop = bubbleRect.top - sheetHeight - margin;
    const top = preferredTop >= margin ? preferredTop : bubbleRect.bottom + margin;

    sheet.style.left = `${Math.round(left)}px`;
    sheet.style.top = `${Math.round(Math.min(top, window.innerHeight - sheetHeight - margin))}px`;
    sheet.style.transformOrigin = preferredTop >= margin ? "bottom right" : "top right";
    sheet.dataset.contextGeneratorPositionLocked = "true";
  }

  function animateDestinationTiles(sheet) {
    if (window.matchMedia?.("(prefers-reduced-motion: reduce)").matches) return;

    const tiles = sheet.querySelectorAll(".context-generator-destination-tile");
    tiles.forEach((tile, index) => {
      tile.classList.remove("context-generator-tile-enter");
      tile.style.animationDelay = `${index * 0.045}s`;
      void tile.offsetWidth;
      tile.classList.add("context-generator-tile-enter");
    });

    window.setTimeout(() => {
      tiles.forEach((tile) => {
        tile.classList.remove("context-generator-tile-enter");
        tile.style.animationDelay = "";
      });
    }, 320);
  }

  function resetDestinationTiles(sheet) {
    sheet.querySelectorAll(".context-generator-destination-tile").forEach((tile) => {
      const accent = tile.dataset.contextGeneratorAccent || "#ffffff";
      const aura = tile.querySelector(".context-generator-tile-aura");
      tile.dataset.contextGeneratorLoading = "false";
      tile.removeAttribute("aria-busy");
      tile.style.pointerEvents = "";
      tile.style.background = "linear-gradient(180deg,rgba(255,255,255,0.055) 0%,rgba(255,255,255,0.022) 100%)";
      tile.style.borderColor = "rgba(255,255,255,0.11)";
      tile.style.boxShadow = "inset 0 1px 0 rgba(255,255,255,0.065), 0 1px 1px rgba(0,0,0,0.32)";
      tile.style.transform = "translateY(0)";
      if (aura) {
        aura.style.left = "10px";
        aura.style.right = "auto";
        aura.style.width = "38px";
        aura.style.borderRadius = "999px";
        aura.style.background = `radial-gradient(ellipse at 22% 50%, ${accent}24 0, ${accent}12 36%, ${accent}04 61%, transparent 80%)`;
        aura.style.opacity = "0.24";
      }
      const detail = tile.querySelector(".context-generator-tile-detail");
      const spinner = tile.querySelector(".context-generator-tile-spinner");
      if (detail && tile.dataset.contextGeneratorDetail) {
        detail.textContent = tile.dataset.contextGeneratorDetail;
      }
      if (spinner) spinner.style.display = "none";
    });
  }

  async function startDestinationTransfer(destinationId) {
    hideDestinationSheet();
    if (isRunning) return;

    const trace = activeTransferTrace || warmSummary?.trace || createTransferTrace(destinationId, "destination tile");
    trace.destinationId = destinationId;
    markTransferTrace(trace, "destination click", { destination: destinationId });

    isRunning = true;
    clearRunningResetTimer();
    runningResetTimer = setTimeout(resetRunningFlag, RUNNING_AUTO_RESET_MS);
    showOverlay(destinationId);
    setHandoffStatus("Reading source chat");
    await prepareSourceForCapture();
    let preparedDestinationPromise = null;
    if (getDetectedConversationMessageCount() > 0) {
      preparedDestinationPromise = prepareDestinationTab(destinationId, trace);
    }

    let conversationText;
    try {
      markTransferTrace(trace, "capture start");
      conversationText = await scrapeConversationTextWhenReady();
      markCaptureDone(trace, conversationText);
    } catch (error) {
      clearWarmSummary();
      markTransferTrace(trace, `failed: ${error.message}`);
      finishTransferTrace(trace);
      resetRunningFlag();
      showErrorOverlay(error.message);
      return;
    }

    const warmSummaryRecord = ensureWarmSummaryForConversation(conversationText, trace);
    preparedDestinationPromise = preparedDestinationPromise || prepareDestinationTab(destinationId, trace);
    runContextFlow(destinationId, preparedDestinationPromise, warmSummaryRecord, conversationText, trace);
  }

  function ensureFloatingOverlay() {
    if (!document.getElementById(OVERLAY_ID)) {
      const overlay = document.createElement("div");
      overlay.id = OVERLAY_ID;
      overlay.dataset.contextGeneratorOwned = "true";
      overlay.style.cssText = [
        "display:none",
        "position:fixed",
        "z-index:2147483647",
        "left:50%",
        "top:46%",
        "width:min(560px,calc(100vw - 32px))",
        "height:240px",
        "min-height:240px",
        "max-height:240px",
        "box-sizing:border-box",
        "padding:36px 40px 32px",
        "border-radius:30px",
        "border:1px solid rgba(226,226,226,0.135)",
        "background:linear-gradient(180deg,#171719 0%,#101012 52%,#0b0b0d 100%)",
        "color:#b9b9b9",
        "box-shadow:0 26px 76px rgba(0,0,0,0.55), 0 0 0 1px rgba(0,0,0,0.7), inset 0 1px 0 rgba(255,255,255,0.075), inset 0 -1px 0 rgba(255,255,255,0.025)",
        "transform:translate3d(-50%,-50%,0) scale(0.98)",
        "opacity:0",
        "flex-direction:column",
        "justify-content:center",
        "gap:30px",
        "overflow:hidden",
        "backdrop-filter:blur(20px)",
        "font-family:'Iowan Old Style','New York',Georgia,'Times New Roman',serif",
        "letter-spacing:0",
        "will-change:transform,opacity",
        "transition:opacity 0.16s cubic-bezier(0.16,1,0.3,1), transform 0.18s cubic-bezier(0.16,1,0.3,1)"
      ].join(";");

      const glow = document.createElement("div");
      glow.style.cssText = [
        "position:absolute",
        "inset:-1px",
        "pointer-events:none",
        "background:radial-gradient(circle at 50% -24%,rgba(255,255,255,0.105),transparent 34%),linear-gradient(180deg,rgba(255,255,255,0.04),transparent 42%,rgba(255,255,255,0.018) 100%)",
        "opacity:0.78"
      ].join(";");

      const topRow = document.createElement("div");
      topRow.style.cssText = "position:relative;z-index:1;display:flex;align-items:center;justify-content:center;text-align:center";

      const mark = document.createElement("div");
      mark.style.cssText = [
        "width:34px",
        "height:34px",
        "border-radius:12px",
        "display:none",
        "align-items:center",
        "justify-content:center",
        "flex:0 0 auto",
        "background:linear-gradient(180deg,rgba(255,255,255,0.11),rgba(255,255,255,0.035))",
        "border:1px solid rgba(255,255,255,0.12)",
        "box-shadow:inset 0 1px 0 rgba(255,255,255,0.08)"
      ].join(";");

      const markDot = document.createElement("div");
      markDot.style.cssText = [
        "width:13px",
        "height:13px",
        "border-radius:999px",
        "background:#ffffff",
        "box-shadow:0 0 0 5px rgba(255,255,255,0.06),0 0 18px rgba(255,255,255,0.34)"
      ].join(";");
      mark.appendChild(markDot);

      const copy = document.createElement("div");
      copy.style.cssText = "min-width:0;display:flex;flex-direction:column;align-items:center;gap:0;flex:1";

      const quote = document.createElement("div");
      quote.id = "context-generator-overlay-quote";
      quote.style.cssText = [
        "font-size:18px",
        "font-weight:500",
        "line-height:1.32",
        "white-space:nowrap",
        "overflow:hidden",
        "text-overflow:ellipsis",
        "max-width:100%",
        "color:transparent",
        "background-image:linear-gradient(100deg,#858585 0%,#bdbdbd 30%,#ededed 46%,#b1b1b1 62%,#757575 100%)",
        "background-size:220% 100%",
        "-webkit-background-clip:text",
        "background-clip:text",
        "animation:contextGeneratorQuoteShimmer 5.2s linear infinite"
      ].join(";");
      quote.textContent = HANDOFF_QUOTES[0];

      copy.appendChild(quote);
      topRow.appendChild(mark);
      topRow.appendChild(copy);

      const statusShell = document.createElement("div");
      statusShell.style.cssText = [
        "position:relative",
        "z-index:1",
        "height:64px",
        "border-radius:22px",
        "border:0",
        "background:transparent",
        "display:flex",
        "align-items:center",
        "justify-content:center",
        "padding:0 22px",
        "box-sizing:border-box",
        "overflow:hidden"
      ].join(";");

      if (!document.getElementById("context-generator-styles")) {
        const styleSheet = document.createElement("style");
        styleSheet.id = "context-generator-styles";
        styleSheet.dataset.contextGeneratorOwned = "true";
        styleSheet.textContent = `
          @keyframes contextGeneratorQuoteShimmer{
            0%{background-position:145% 50%}
            100%{background-position:-115% 50%}
          }
          @keyframes contextGeneratorStatusShimmer{
            0%{opacity:0;transform:translate3d(0,14px,0);background-position:122% 50%;filter:blur(0.2px)}
            18%{opacity:1;transform:translate3d(0,0,0);filter:blur(0)}
            56%{opacity:1;transform:translate3d(0,0,0);background-position:0% 50%}
            84%{opacity:1;transform:translate3d(0,0,0);background-position:-42% 50%}
            100%{opacity:0;transform:translate3d(0,-13px,0);background-position:-88% 50%;filter:blur(0.15px)}
          }
          @media (prefers-reduced-motion: reduce){
            #context-generator-text{animation:none!important}
            #context-generator-overlay-quote{animation:none!important}
          }
        `;
        document.head.appendChild(styleSheet);
      }

      const textSpan = document.createElement("span");
      textSpan.id = "context-generator-text";
      textSpan.textContent = "Summarizing context";
      textSpan.style.cssText = [
        "display:block",
        "width:100%",
        "min-width:0",
        "font-size:30px",
        "font-weight:500",
        "line-height:1.18",
        "text-align:center",
        "white-space:nowrap",
        "overflow:hidden",
        "text-overflow:ellipsis",
        "color:transparent",
        "background-image:linear-gradient(100deg,#8a8a8a 0%,#c6c6c6 28%,#f1f1f1 44%,#b6b6b6 60%,#747474 100%)",
        "background-size:220% 100%",
        "background-position:125% 50%",
        "-webkit-background-clip:text",
        "background-clip:text",
        "animation:contextGeneratorStatusShimmer 1.72s cubic-bezier(0.16,1,0.3,1) both"
      ].join(";");
      statusShell.appendChild(textSpan);

      const countdown = document.createElement("div");
      countdown.id = HANDOFF_COUNTDOWN_ID;
      countdown.setAttribute("aria-label", "Estimated seconds remaining");
      countdown.style.cssText = [
        "position:absolute",
        "z-index:2",
        "right:24px",
        "bottom:20px",
        "display:none",
        "align-items:center",
        "justify-content:center",
        "min-width:34px",
        "height:24px",
        "padding:0 9px",
        "box-sizing:border-box",
        "border-radius:999px",
        "border:1px solid rgba(255,255,255,0.085)",
        "background:rgba(255,255,255,0.045)",
        "box-shadow:inset 0 1px 0 rgba(255,255,255,0.045)",
        "color:rgba(255,255,255,0.48)",
        "font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif",
        "font-size:11px",
        "font-weight:650",
        "line-height:1",
        "letter-spacing:0",
        "opacity:0",
        "transition:opacity 160ms ease"
      ].join(";");

      overlay.appendChild(glow);
      overlay.appendChild(topRow);
      overlay.appendChild(statusShell);
      overlay.appendChild(countdown);
      document.body.appendChild(overlay);
    }
  }

  function showOverlay(destinationId = null) {
    ensureFloatingOverlay();
    const overlay = document.getElementById(OVERLAY_ID);
    const quote = document.getElementById("context-generator-overlay-quote");
    const bubble = document.getElementById(BUBBLE_ID);
    const destination = destinationId ? getPlatform(destinationId) : null;

    if (overlay) {
      if (quote) {
        quote.textContent = getRandomHandoffQuote();
      }
      startHandoffStatusCycle(destination?.name || "destination");
      startHandoffCountdown();
      overlay.style.display = "flex";
      requestAnimationFrame(() => {
        overlay.style.opacity = "1";
        overlay.style.transform = "translate3d(-50%,-50%,0) scale(1)";
      });
    }

    if (bubble) {
      bubble.disabled = true;
      bubble.style.opacity = "0.5";
      bubble.style.cursor = "not-allowed";
    }
  }

  function hideOverlay() {
    const overlay = document.getElementById(OVERLAY_ID);
    const bubble = document.getElementById(BUBBLE_ID);

    stopHandoffStatusCycle();
    stopHandoffCountdown();
    if (overlay) {
      overlay.style.opacity = "0";
      overlay.style.transform = "translate3d(-50%,-50%,0) scale(0.98)";
      overlay.style.display = "none";
    }
    if (bubble) {
      bubble.disabled = false;
      bubble.style.opacity = "1";
      bubble.style.cursor = "pointer";
    }
  }

  function isHandoffOverlayVisible() {
    const overlay = document.getElementById(OVERLAY_ID);
    return Boolean(overlay && overlay.style.display !== "none");
  }

  function startHandoffStatusCycle(destinationName) {
    stopHandoffStatusCycle();
    const steps = HANDOFF_STATUS_STEPS.map((step) => step.replace("{destination}", destinationName));
    handoffStatusIndex = 0;
    setHandoffStatus(steps[handoffStatusIndex]);

    handoffStatusTimer = window.setInterval(() => {
      handoffStatusIndex = (handoffStatusIndex + 1) % steps.length;
      setHandoffStatus(steps[handoffStatusIndex]);
    }, HANDOFF_STATUS_INTERVAL_MS);
  }

  function setHandoffStatus(text) {
    const textSpan = document.getElementById("context-generator-text");
    if (!textSpan || !text) return;

    textSpan.style.animation = "none";
    textSpan.textContent = text;
    void textSpan.offsetWidth;
    textSpan.style.animation = "contextGeneratorStatusShimmer 1.72s cubic-bezier(0.16,1,0.3,1) both";
  }

  function startHandoffCountdown() {
    stopHandoffCountdown();
    const countdown = document.getElementById(HANDOFF_COUNTDOWN_ID);
    if (!countdown) return;

    const startMs = HANDOFF_COUNTDOWN_FIXED_MS;
    const startedAt = getNow();
    countdown.style.display = "inline-flex";
    countdown.style.opacity = "1";

    const updateCountdown = () => {
      const remainingMs = startMs - (getNow() - startedAt);
      if (remainingMs <= 0) {
        hideHandoffCountdown(countdown);
        return;
      }

      countdown.textContent = `${Math.max(1, Math.ceil(remainingMs / 1000))}s`;
    };

    updateCountdown();
    handoffCountdownTimer = window.setInterval(updateCountdown, 250);
  }

  function hideHandoffCountdown(countdown = document.getElementById(HANDOFF_COUNTDOWN_ID)) {
    if (handoffCountdownTimer) {
      clearInterval(handoffCountdownTimer);
      handoffCountdownTimer = null;
    }
    if (!countdown) return;

    countdown.style.opacity = "0";
    handoffCountdownHideTimer = window.setTimeout(() => {
      countdown.style.display = "none";
      handoffCountdownHideTimer = null;
    }, 170);
  }

  function stopHandoffStatusCycle() {
    if (handoffStatusTimer) {
      clearInterval(handoffStatusTimer);
      handoffStatusTimer = null;
    }
  }

  function stopHandoffCountdown() {
    if (handoffCountdownTimer) {
      clearInterval(handoffCountdownTimer);
      handoffCountdownTimer = null;
    }
    if (handoffCountdownHideTimer) {
      clearTimeout(handoffCountdownHideTimer);
      handoffCountdownHideTimer = null;
    }

    const countdown = document.getElementById(HANDOFF_COUNTDOWN_ID);
    if (countdown) {
      countdown.style.opacity = "0";
      countdown.style.display = "none";
    }
  }

  function getRandomHandoffQuote() {
    return HANDOFF_QUOTES[Math.floor(Math.random() * HANDOFF_QUOTES.length)] || HANDOFF_QUOTES[0];
  }

  function showErrorOverlay(message) {
    const isNoConversationError = message === NO_CONVERSATION_ERROR_MESSAGE;
    const isSummaryRetryError = message === SUMMARY_RETRY_ERROR_MESSAGE;
    let errorDiv = document.getElementById("context-generator-error-overlay");
    if (!errorDiv) {
      errorDiv = document.createElement("div");
      errorDiv.id = "context-generator-error-overlay";
      errorDiv.dataset.contextGeneratorOwned = "true";
      errorDiv.style.cssText = [
        "position:fixed",
        "z-index:9999999",
        "right:20px",
        "bottom:80px",
        "width:min(340px,calc(100vw - 32px))",
        "box-sizing:border-box",
        "padding:14px",
        "border-radius:16px",
        "border:1px solid rgba(255,255,255,0.12)",
        "background:linear-gradient(145deg,#111111 0%,#171721 58%,#101015 100%)",
        "color:#ffffff",
        "box-shadow:0 18px 44px rgba(0,0,0,0.38), inset 0 1px 0 rgba(255,255,255,0.06)",
        "font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif",
        "display:none",
        "opacity:0",
        "transform:translate3d(24px,0,0)",
        "transition:opacity 260ms ease,transform 260ms ease",
        "flex-direction:column",
        "gap:12px",
        "overflow:hidden"
      ].join(";");

      const accent = document.createElement("div");
      accent.style.cssText = [
        "position:absolute",
        "inset:-1px",
        "pointer-events:none",
        "background:radial-gradient(circle at 12% 18%,rgba(120,95,255,0.24),transparent 34%),radial-gradient(circle at 88% 96%,rgba(25,195,125,0.16),transparent 32%)",
        "opacity:0.9"
      ].join(";");

      const header = document.createElement("div");
      header.style.cssText = "position:relative;z-index:1;display:flex;align-items:center;gap:10px";

      const mark = document.createElement("div");
      mark.id = "context-generator-error-mark";
      mark.style.cssText = [
        "width:28px",
        "height:28px",
        "border-radius:999px",
        "display:flex",
        "align-items:center",
        "justify-content:center",
        "flex:0 0 auto",
        "font-size:14px",
        "font-weight:800",
        "background:rgba(255,255,255,0.08)",
        "border:1px solid rgba(255,255,255,0.14)",
        "color:#ffffff"
      ].join(";");

      const title = document.createElement("div");
      title.id = "context-generator-error-title";
      title.style.cssText = "font-size:14px;font-weight:760;line-height:1.2;letter-spacing:0;color:#ffffff";

      const textSpan = document.createElement("span");
      textSpan.id = "context-generator-error-text";
      textSpan.style.cssText = "position:relative;z-index:1;font-size:12.5px;font-weight:500;line-height:1.42;color:rgba(255,255,255,0.72)";

      const closeBtn = document.createElement("button");
      closeBtn.textContent = "Dismiss";
      closeBtn.style.cssText = [
        "position:relative",
        "z-index:1",
        "align-self:flex-end",
        "height:28px",
        "padding:0 11px",
        "border-radius:999px",
        "border:1px solid rgba(255,255,255,0.12)",
        "background:rgba(255,255,255,0.07)",
        "color:rgba(255,255,255,0.86)",
        "cursor:pointer",
        "font:inherit",
        "font-size:12px",
        "font-weight:650",
        "line-height:28px"
      ].join(";");
      closeBtn.addEventListener("click", () => {
        hideErrorOverlay(errorDiv);
      });

      header.appendChild(mark);
      header.appendChild(title);
      errorDiv.appendChild(accent);
      errorDiv.appendChild(header);
      errorDiv.appendChild(textSpan);
      errorDiv.appendChild(closeBtn);
      document.body.appendChild(errorDiv);
    }

    const title = document.getElementById("context-generator-error-title");
    if (title) {
      title.textContent = isNoConversationError
        ? NO_CONVERSATION_ERROR_TITLE
        : isSummaryRetryError
          ? SUMMARY_RETRY_ERROR_TITLE
          : "Transfer failed";
    }

    const mark = document.getElementById("context-generator-error-mark");
    if (mark) {
      mark.textContent = isNoConversationError || isSummaryRetryError ? "i" : "!";
    }

    const textSpan = document.getElementById("context-generator-error-text");
    if (textSpan) {
      textSpan.textContent = message;
    }

    clearTimeout(errorDiv.contextGeneratorHideTimer);
    clearTimeout(errorDiv.contextGeneratorDisplayTimer);
    errorDiv.style.display = "flex";
    errorDiv.style.opacity = "0";
    errorDiv.style.transform = "translate3d(24px,0,0)";
    requestAnimationFrame(() => {
      errorDiv.style.opacity = "1";
      errorDiv.style.transform = "translate3d(0,0,0)";
    });
    errorDiv.contextGeneratorHideTimer = setTimeout(() => {
      hideErrorOverlay(errorDiv);
    }, 8000);
  }

  function hideErrorOverlay(errorDiv = document.getElementById("context-generator-error-overlay")) {
    if (!errorDiv) return;
    clearTimeout(errorDiv.contextGeneratorDisplayTimer);
    errorDiv.style.opacity = "0";
    errorDiv.style.transform = "translate3d(24px,0,0)";
    errorDiv.contextGeneratorDisplayTimer = setTimeout(() => {
      errorDiv.style.display = "none";
    }, 280);
  }

  function showFallbackModal(text, destinationName) {
    let modal = document.getElementById("context-generator-fallback-modal");
    if (!modal) {
      modal = document.createElement("div");
      modal.id = "context-generator-fallback-modal";
      modal.dataset.contextGeneratorOwned = "true";
      modal.setAttribute("role", "dialog");
      modal.setAttribute("aria-modal", "true");
      modal.setAttribute("aria-labelledby", "context-generator-fallback-title");
      modal.setAttribute("aria-describedby", "context-generator-fallback-desc");
      modal.style.cssText = [
        "position:fixed",
        "z-index:2147483647",
        "inset:0",
        "display:flex",
        "align-items:center",
        "justify-content:center",
        "box-sizing:border-box",
        "padding:18px",
        "background:rgba(0,0,0,0.68)",
        "backdrop-filter:blur(12px)",
        "font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif"
      ].join(";");

      const content = document.createElement("div");
      content.style.cssText = [
        "position:relative",
        "width:min(560px,100%)",
        "box-sizing:border-box",
        "display:flex",
        "flex-direction:column",
        "gap:16px",
        "padding:26px",
        "border-radius:26px",
        "border:1px solid rgba(255,255,255,0.14)",
        "background:linear-gradient(180deg,#171719 0%,#101012 58%,#09090b 100%)",
        "color:#f5f5f5",
        "box-shadow:0 28px 84px rgba(0,0,0,0.58),0 0 0 1px rgba(0,0,0,0.72),inset 0 1px 0 rgba(255,255,255,0.08)",
        "overflow:hidden"
      ].join(";");

      const accent = document.createElement("div");
      accent.style.cssText = [
        "position:absolute",
        "inset:-1px",
        "pointer-events:none",
        "background:radial-gradient(circle at 50% -18%,rgba(255,255,255,0.12),transparent 36%),linear-gradient(180deg,rgba(255,255,255,0.045),transparent 48%)"
      ].join(";");

      const header = document.createElement("div");
      header.style.cssText = "position:relative;z-index:1;display:flex;align-items:flex-start;justify-content:space-between;gap:16px";

      const copyWrap = document.createElement("div");
      copyWrap.style.cssText = "display:flex;flex-direction:column;gap:7px;min-width:0";

      const title = document.createElement("div");
      title.id = "context-generator-fallback-title";
      title.style.cssText = [
        "font-family:Georgia,'Times New Roman',serif",
        "font-size:22px",
        "font-weight:500",
        "line-height:1.1",
        "letter-spacing:0",
        "color:#ffffff"
      ].join(";");
      title.textContent = "Context is ready to copy";

      const desc = document.createElement("div");
      desc.id = "context-generator-fallback-desc";
      desc.style.cssText = [
        "font-size:13px",
        "line-height:1.5",
        "color:rgba(255,255,255,0.64)",
        "max-width:430px"
      ].join(";");

      const dismissBtn = document.createElement("button");
      dismissBtn.id = "context-generator-fallback-dismiss";
      dismissBtn.type = "button";
      dismissBtn.textContent = "Close";
      dismissBtn.style.cssText = [
        "height:32px",
        "padding:0 12px",
        "border-radius:999px",
        "border:1px solid rgba(255,255,255,0.14)",
        "background:rgba(255,255,255,0.045)",
        "color:rgba(255,255,255,0.72)",
        "font-size:12px",
        "font-weight:650",
        "cursor:pointer"
      ].join(";");

      const textarea = document.createElement("textarea");
      textarea.id = "context-generator-fallback-text";
      textarea.readOnly = true;
      textarea.setAttribute("aria-label", "Generated context to copy");
      textarea.style.cssText = [
        "position:relative",
        "z-index:1",
        "height:min(230px,38vh)",
        "min-height:150px",
        "box-sizing:border-box",
        "resize:vertical",
        "padding:14px",
        "border-radius:14px",
        "border:1px solid rgba(255,255,255,0.13)",
        "background:rgba(0,0,0,0.34)",
        "box-shadow:inset 0 1px 0 rgba(255,255,255,0.04)",
        "color:#f0f0f0",
        "font-family:'SFMono-Regular',Consolas,'Liberation Mono',monospace",
        "font-size:12px",
        "line-height:1.5",
        "outline:none"
      ].join(";");

      const buttonContainer = document.createElement("div");
      buttonContainer.style.cssText = "position:relative;z-index:1;display:flex;justify-content:flex-end;gap:10px;flex-wrap:wrap";

      const copyBtn = document.createElement("button");
      copyBtn.id = "context-generator-fallback-copy";
      copyBtn.type = "button";
      copyBtn.textContent = "Copy Context";
      copyBtn.style.cssText = [
        "height:38px",
        "padding:0 16px",
        "border-radius:999px",
        "border:1px solid rgba(255,255,255,0.18)",
        "background:linear-gradient(180deg,#f5f5f5,#d8d8d8)",
        "box-shadow:0 10px 24px rgba(0,0,0,0.24),inset 0 1px 0 rgba(255,255,255,0.7)",
        "color:#111114",
        "font-size:13px",
        "font-weight:750",
        "cursor:pointer"
      ].join(";");

      const setFocusStyle = (button, active) => {
        button.style.outline = active ? "2px solid rgba(255,255,255,0.42)" : "none";
        button.style.outlineOffset = active ? "3px" : "0";
      };

      copyBtn.addEventListener("click", async () => {
        const currentText = textarea.value || "";
        try {
          if (!navigator.clipboard?.writeText) throw new Error("Clipboard API unavailable.");
          await navigator.clipboard.writeText(currentText);
          copyBtn.textContent = "Copied!";
          copyBtn.style.background = "linear-gradient(180deg,#69e6a2,#21b36b)";
          copyBtn.style.color = "#07150d";
          setTimeout(() => {
            if (!copyBtn.isConnected) return;
            copyBtn.textContent = "Copy Context";
            copyBtn.style.background = "linear-gradient(180deg,#f5f5f5,#d8d8d8)";
            copyBtn.style.color = "#111114";
          }, 2000);
        } catch (err) {
          textarea.select();
          document.execCommand("copy");
          copyBtn.textContent = "Copied!";
          copyBtn.style.background = "linear-gradient(180deg,#69e6a2,#21b36b)";
          copyBtn.style.color = "#07150d";
        }
      });

      const closeModal = () => {
        document.removeEventListener("keydown", modal.contextGeneratorKeydownHandler);
        const previousFocus = modal.contextGeneratorPreviousFocus;
        modal.remove();
        setTimeout(() => previousFocus?.focus?.({ preventScroll: true }), 0);
      };

      modal.contextGeneratorKeydownHandler = (event) => {
        if (event.key === "Escape") {
          event.preventDefault();
          closeModal();
          return;
        }

        if (event.key !== "Tab") return;

        const focusable = Array.from(modal.querySelectorAll("button, textarea"))
          .filter((node) => !node.disabled && node.offsetParent !== null);
        if (!focusable.length) return;

        const first = focusable[0];
        const last = focusable[focusable.length - 1];
        if (event.shiftKey && document.activeElement === first) {
          event.preventDefault();
          last.focus();
        } else if (!event.shiftKey && document.activeElement === last) {
          event.preventDefault();
          first.focus();
        }
      };

      modal.contextGeneratorClose = closeModal;
      modal.addEventListener("click", (event) => {
        if (event.target === modal) closeModal();
      });
      content.addEventListener("click", (event) => event.stopPropagation());
      [copyBtn, dismissBtn].forEach((button) => {
        button.addEventListener("focus", () => setFocusStyle(button, true));
        button.addEventListener("blur", () => setFocusStyle(button, false));
      });
      dismissBtn.addEventListener("click", closeModal);

      copyWrap.appendChild(title);
      copyWrap.appendChild(desc);
      header.appendChild(copyWrap);
      header.appendChild(dismissBtn);

      content.appendChild(accent);
      content.appendChild(header);
      content.appendChild(textarea);
      content.appendChild(buttonContainer);
      buttonContainer.appendChild(copyBtn);
      modal.appendChild(content);
      document.body.appendChild(modal);
      document.addEventListener("keydown", modal.contextGeneratorKeydownHandler);
    } else {
      modal.style.display = "flex";
      if (!modal.contextGeneratorKeydownHandler) {
        modal.contextGeneratorKeydownHandler = (event) => {
          if (event.key === "Escape") {
            event.preventDefault();
            modal.contextGeneratorClose?.();
          }
        };
        document.addEventListener("keydown", modal.contextGeneratorKeydownHandler);
      }
    }

    modal.contextGeneratorPreviousFocus = document.activeElement;

    const desc = document.getElementById("context-generator-fallback-desc");
    if (desc) {
      desc.textContent = `Auto-paste did not land in ${destinationName}. The context is safe here - copy it, paste it into the message box, then send when ready.`;
    }

    const textarea = document.getElementById("context-generator-fallback-text");
    if (textarea) {
      textarea.value = text;
      textarea.scrollTop = 0;
    }

    setTimeout(() => {
      document.getElementById("context-generator-fallback-copy")?.focus?.({ preventScroll: true });
    }, 0);
  }

  function updateFloatingButtonPosition() {
    const bubble = document.getElementById(BUBBLE_ID);
    const input = findPlatformInput();
    if (!bubble || !input) return;

    if (currentPlatform.id === "chatgpt") {
      releaseBubbleSlot();
      releaseComposerSurface();
      const floatingRoot = getFloatingButtonRoot();
      if (bubble.parentElement !== floatingRoot) {
        floatingRoot.appendChild(bubble);
      }

      setBubbleFixedMode(bubble);
      const placement = getChatGptFixedBubblePlacement(input);
      bubble.style.left = `${placement.left}px`;
      bubble.style.right = "auto";
      bubble.style.top = `${placement.top}px`;
      bubble.style.display = "flex";
      maybeShowOnboardingNudge(bubble);
      return;
    }

    const composerSurface = findComposerSurfaceElement(input);
    if (!composerSurface) {
      bubble.style.display = "none";
      hideOnboardingNudge();
      return;
    }

    reserveComposerSurface(composerSurface);

    if (currentPlatform.id !== "chatgpt" && bubble.parentElement !== composerSurface) {
      composerSurface.appendChild(bubble);
    }

    const composerRect = composerSurface.getBoundingClientRect();
    if (
      composerRect.width < 280 ||
      composerRect.height < 20 ||
      composerRect.bottom < 0 ||
      composerRect.top > window.innerHeight
    ) {
      bubble.style.display = "none";
      hideOnboardingNudge();
      return;
    }

    setBubbleAbsoluteMode(bubble);

    if (currentPlatform.id === "grok") {
      const grokPlacement = getGrokBubblePlacement(composerRect);
      releaseBubbleSlot();
      bubble.style.left = `${grokPlacement.left}px`;
      bubble.style.right = "auto";
      bubble.style.top = `${grokPlacement.top}px`;
      bubble.style.display = "flex";
      maybeShowOnboardingNudge(bubble);
      return;
    }

    if (currentPlatform.id === "deepseek") {
      const deepSeekPlacement = getDeepSeekBubblePlacement(composerRect);
      if (deepSeekPlacement) {
        releaseBubbleSlot();
        bubble.style.left = `${deepSeekPlacement.left}px`;
        bubble.style.right = "auto";
        bubble.style.top = `${deepSeekPlacement.top}px`;
        bubble.style.display = "flex";
        maybeShowOnboardingNudge(bubble);
        return;
      }
    }

    if (currentPlatform.id === "gemini") {
      const geminiAnchor =
        findGeminiModelSelectorButton(composerRect) ||
        findComposerActionButton(input, composerRect);
      const geminiPlacement = getGeminiBubblePlacement(
        composerRect,
        geminiAnchor
      );
      releaseBubbleSlot();
      bubble.style.left = "auto";
      bubble.style.right = `${geminiPlacement.right}px`;
      bubble.style.top = "auto";
      bubble.style.bottom = `${geminiPlacement.bottom}px`;
      bubble.style.display = "flex";
      maybeShowOnboardingNudge(bubble);
      return;
    }

    if (currentPlatform.id === "claude") {
      const claudePlacement = getClaudeBubblePlacement(composerRect, input);
      if (claudePlacement.anchorControl) {
        reserveClaudeInlineBubbleSlot(claudePlacement.anchorControl, claudePlacement.controls, input, composerRect, claudePlacement.inlineShift);
      } else {
        releaseBubbleSlot();
      }
      setBubbleStylesIfChanged(bubble, {
        left: `${claudePlacement.left}px`,
        right: "auto",
        top: `${claudePlacement.top}px`,
        bottom: "auto",
        display: "flex"
      });
      maybeShowOnboardingNudge(bubble);
      return;
    }

    const actionBtn = findComposerActionButton(input, composerRect);
    let anchorTop = composerRect.bottom - BUBBLE_SIZE - BUBBLE_GAP;

    if (actionBtn) {
      const actionRect = actionBtn.getBoundingClientRect();
      if (actionRect.width > 0 && actionRect.height > 0) {
        reserveBubbleSlot(actionBtn, input);
        anchorTop = actionRect.top + (actionRect.height - BUBBLE_SIZE) / 2;
      }
    } else {
      releaseBubbleSlot();
    }

    const right = BUBBLE_GAP;
    const top = Math.max(
      BUBBLE_GAP,
      Math.min(
        anchorTop - composerRect.top,
        composerRect.height - BUBBLE_SIZE - BUBBLE_GAP
      )
    );

    bubble.style.left = "auto";
    bubble.style.right = `${right}px`;
    bubble.style.top = `${Math.round(top)}px`;
    bubble.style.display = "flex";
    maybeShowOnboardingNudge(bubble);
  }

  function findComposerActionButton(input, composerRect) {
    if (!input || !composerRect) return null;

    const buttons = Array.from(document.querySelectorAll("button")).filter((button) => {
      return button.id !== BUBBLE_ID && isVisible(button);
    });

    const composerButtons = buttons.filter((button) => {
      const rect = button.getBoundingClientRect();
      const centerX = rect.left + rect.width / 2;
      return (
        centerX >= composerRect.left + composerRect.width * 0.45 &&
        rect.left >= composerRect.left - 12 &&
        rect.right <= composerRect.right + 12 &&
        rect.top >= composerRect.top - 12 &&
        rect.bottom <= composerRect.bottom + 12
      );
    });

    if (composerButtons.length === 0) return null;

    return composerButtons.reduce((rightmost, button) => {
      const rightmostRect = rightmost.getBoundingClientRect();
      const buttonRect = button.getBoundingClientRect();
      if (buttonRect.right !== rightmostRect.right) {
        return buttonRect.right > rightmostRect.right ? button : rightmost;
      }
      return buttonRect.left > rightmostRect.left ? button : rightmost;
    });
  }

  function getClaudeBubblePlacement(composerRect, input = null) {
    const controls = getClaudeComposerControlCandidates(composerRect);
    const anchorControl = findClaudeVoiceModeControl(controls) || findClaudeInlineFallbackControl(controls);

    if (anchorControl) {
      const currentOffset = getClaudeCurrentControlOffset(anchorControl);
      const baseAnchorRight = anchorControl.rect.right - currentOffset;
      const anchorNudge = getClaudeControlTargetOffset(anchorControl, 0);
      const maxLeft = Math.max(
        BUBBLE_GAP,
        composerRect.width - BUBBLE_SIZE - CLAUDE_INLINE_RIGHT_MARGIN
      );
      const preferredLeft = baseAnchorRight + anchorNudge - composerRect.left + CLAUDE_INLINE_BUBBLE_GAP;
      const inlineShift = Math.min(
        CLAUDE_INLINE_SLOT_WIDTH,
        Math.max(0, preferredLeft - maxLeft)
      );
      const left = clampNumber(
        baseAnchorRight + getClaudeControlTargetOffset(anchorControl, inlineShift) - composerRect.left + CLAUDE_INLINE_BUBBLE_GAP,
        BUBBLE_GAP,
        maxLeft
      );
      const top = getBubblePlacementBesideRect(anchorControl.rect, composerRect, left).top;

      return {
        left: Math.round(left),
        top,
        inlineShift: Math.round(inlineShift),
        anchorControl,
        controls
      };
    }

    return {
      ...getBottomRightRowBubblePlacement(composerRect, 16),
      inlineShift: 0,
      anchorControl: null,
      controls
    };
  }

  function getClaudeComposerControlCandidates(composerRect) {
    const rowTop = getClaudeComposerControlRowTop(composerRect);

    return Array.from(document.querySelectorAll("button, [role='button'], [tabindex='0']"))
      .filter((element) => element.id !== BUBBLE_ID && !isContextGeneratorNode(element) && isVisible(element))
      .map((element) => ({
        element,
        label: getElementLabel(element, true),
        rect: element.getBoundingClientRect()
      }))
      .filter(({ rect }) => {
        return (
          rect.width > 0 &&
          rect.width <= 280 &&
          rect.height > 0 &&
          rect.height <= 84 &&
          rect.left >= composerRect.left - 12 &&
          rect.right <= composerRect.right + 16 &&
          rect.top >= rowTop &&
          rect.bottom <= composerRect.bottom + 16
        );
      })
      .sort((a, b) => a.rect.left - b.rect.left);
  }

  function findClaudeVoiceModeControl(controls) {
    return controls
      .map((control) => {
        let score = 0;
        if (/\bvoice\s*mode\b/.test(control.label)) score += 260;
        if (/\b(voice|speak|speech|talk|dictation|audio)\b/.test(control.label)) score += 160;
        if (control.rect.width <= 64 && control.rect.right >= getRightmostControlEdge(controls) - 4) score += 90;
        if (/\b(send|submit|attach|upload|file|project|sidebar|side bar|menu|navigation|toggle|model)\b/.test(control.label)) {
          score -= 260;
        }
        if (/\b(mic|microphone)\b/.test(control.label) && !/\bvoice\b/.test(control.label)) {
          score -= 80;
        }

        return { ...control, score };
      })
      .filter(({ score }) => score >= 160)
      .sort((a, b) => {
        if (b.score !== a.score) return b.score - a.score;
        return b.rect.right - a.rect.right;
      })[0] || null;
  }

  function findClaudeInlineFallbackControl(controls) {
    return controls
      .filter((control) => {
        return (
          control.rect.width <= 72 &&
          !/\b(attach|upload|file|project|sidebar|side bar|menu|navigation|toggle|model)\b/.test(control.label)
        );
      })
      .sort((a, b) => b.rect.right - a.rect.right)[0] || null;
  }

  function getRightmostControlEdge(controls) {
    return controls.reduce((right, control) => Math.max(right, control.rect.right), 0);
  }

  function getClaudeCurrentControlOffset(anchorControl) {
    if (!anchorControl) return 0;
    return reservedClaudeControlOffsets.get(anchorControl.element) || 0;
  }

  function getClaudeComposerControlRowTop(composerRect) {
    return composerRect.bottom - Math.max(72, composerRect.height * 0.62);
  }

  function findChatGptModelSelectorButton(composerSurface, composerRect) {
    const root = composerSurface || document;
    const rowTop = composerRect ? composerRect.bottom - Math.max(64, composerRect.height * 0.65) : window.innerHeight * 0.45;
    const rowBottom = composerRect ? composerRect.bottom + 16 : window.innerHeight - BUBBLE_GAP;
    const scopeLeft = composerRect ? composerRect.left - 12 : window.innerWidth * 0.22;
    const scopeRight = composerRect ? composerRect.right + 12 : window.innerWidth - BUBBLE_GAP;

    return Array.from(root.querySelectorAll("button, [role='button']"))
      .filter((button) => button.id !== BUBBLE_ID && !isContextGeneratorNode(button) && isVisible(button))
      .map((button) => {
        const rect = button.getBoundingClientRect();
        const label = getElementLabel(button, true);
        const text = (button.innerText || button.textContent || "").toLowerCase();
        let score = 0;

        if (/\b(instant|medium|high)\b/.test(text)) score += 180;
        if (/\b(model|intelligence|reasoning|thinking)\b/.test(label)) score += 42;
        if (composerRect && rect.left >= composerRect.left + composerRect.width * 0.45) score += 22;
        if (!composerRect && rect.left >= window.innerWidth * 0.45) score += 12;
        if (rect.top >= rowTop && rect.bottom <= rowBottom) score += 28;
        if (rect.width >= 48 && rect.width <= 140) score += 12;
        if (/\b(send|voice|mic|microphone|attach|upload|tools|image|canvas)\b/.test(label)) score -= 120;

        return { button, rect, score };
      })
      .filter(({ rect, score }) => {
        return (
          score >= 120 &&
          rect.width > 0 &&
          rect.height > 0 &&
          rect.height <= 56 &&
          rect.left >= scopeLeft &&
          rect.right <= scopeRight &&
          rect.top >= rowTop &&
          rect.bottom <= rowBottom
        );
      })
      .sort((a, b) => {
        if (b.score !== a.score) return b.score - a.score;
        return b.rect.left - a.rect.left;
      })[0]?.button || null;
  }

  function setBubbleAbsoluteMode(bubble) {
    setBubbleSize(bubble, BUBBLE_SIZE);
    bubble.style.position = "absolute";
    bubble.style.margin = "0";
    bubble.style.flex = "0 0 auto";
    bubble.style.alignSelf = "auto";
    bubble.style.opacity = "1";
    bubble.style.visibility = "visible";
    bubble.style.overflow = "hidden";
  }

  function setBubbleFixedMode(bubble) {
    setBubbleSize(bubble, BUBBLE_SIZE);
    bubble.style.position = "fixed";
    bubble.style.zIndex = "2147483647";
    bubble.style.margin = "0";
    bubble.style.flex = "0 0 auto";
    bubble.style.alignSelf = "auto";
    bubble.style.opacity = "1";
    bubble.style.visibility = "visible";
    bubble.style.overflow = "hidden";
  }

  function getFloatingButtonRoot() {
    return document.body || document.documentElement;
  }

  function setBubbleSize(bubble, size) {
    bubble.style.width = `${size}px`;
    bubble.style.height = `${size}px`;
    bubble.style.minWidth = `${size}px`;
    bubble.style.minHeight = `${size}px`;
    bubble.style.maxWidth = `${size}px`;
    bubble.style.maxHeight = `${size}px`;

    const icon = bubble.querySelector("img");
    if (icon) {
      const iconSize = Math.max(24, size - 4);
      icon.style.width = `${iconSize}px`;
      icon.style.height = `${iconSize}px`;
    }
  }

  function getChatGptFixedBubblePlacement(input) {
    const composerRect = getChatGptPlacementRect(input);
    const modelButton = findChatGptModelSelectorButton(document, composerRect);

    if (modelButton) {
      return getFixedBubblePlacementBesideRect(modelButton.getBoundingClientRect());
    }

    if (composerRect) {
      const rowButtons = getChatGptComposerButtonCandidates(composerRect);
      const actionButton = rowButtons[rowButtons.length - 1];

      if (actionButton) {
        return getFixedBubblePlacementBesideRect(actionButton.rect);
      }

      const fallback = getBottomRightRowBubblePlacement(composerRect, 64);
      return clampFixedBubblePlacement(composerRect.left + fallback.left, composerRect.top + fallback.top);
    }

    const inputRect = input.getBoundingClientRect();
    return clampFixedBubblePlacement(
      inputRect.right - BUBBLE_SIZE - 112,
      inputRect.top + (inputRect.height - BUBBLE_SIZE) / 2
    );
  }

  function getChatGptPlacementRect(input) {
    const composerSurface = findComposerSurfaceElement(input);
    const composerRect = composerSurface?.getBoundingClientRect();
    if (isUsableChatGptPlacementRect(composerRect)) return composerRect;

    const formRect = input.closest("form")?.getBoundingClientRect();
    if (isUsableChatGptPlacementRect(formRect)) return formRect;

    const inputRect = input.getBoundingClientRect();
    if (!inputRect || inputRect.width <= 0 || inputRect.height <= 0) return null;

    let left = Math.max(BUBBLE_GAP, inputRect.left - 64);
    const right = Math.min(window.innerWidth - BUBBLE_GAP, Math.max(inputRect.right + 180, left + 320));
    if (right - left < 280) {
      left = Math.max(BUBBLE_GAP, right - 320);
    }
    const top = Math.max(BUBBLE_GAP, inputRect.top - 18);
    const bottom = Math.min(window.innerHeight - BUBBLE_GAP, Math.max(inputRect.bottom + 70, top + 96));

    return {
      left,
      right,
      top,
      bottom,
      width: right - left,
      height: bottom - top
    };
  }

  function isUsableChatGptPlacementRect(rect) {
    return Boolean(
      rect &&
      rect.width >= 280 &&
      rect.height >= 40 &&
      rect.bottom >= BUBBLE_GAP &&
      rect.top <= window.innerHeight - BUBBLE_GAP &&
      rect.right >= BUBBLE_GAP &&
      rect.left <= window.innerWidth - BUBBLE_GAP
    );
  }

  function getFixedBubblePlacementBesideRect(targetRect) {
    return clampFixedBubblePlacement(
      targetRect.left - BUBBLE_SIZE - BUBBLE_GAP,
      targetRect.top + (targetRect.height - BUBBLE_SIZE) / 2
    );
  }

  function clampFixedBubblePlacement(left, top) {
    const minLeft = BUBBLE_GAP;
    const minTop = BUBBLE_GAP;
    const maxLeft = Math.max(minLeft, window.innerWidth - BUBBLE_SIZE - BUBBLE_GAP);
    const maxTop = Math.max(minTop, window.innerHeight - BUBBLE_SIZE - BUBBLE_GAP);

    return {
      left: Math.round(Math.min(Math.max(left, minLeft), maxLeft)),
      top: Math.round(Math.min(Math.max(top, minTop), maxTop))
    };
  }

  function getChatGptBubblePlacement(composerRect, composerSurface = null) {
    const modelButton = composerSurface ? findChatGptModelSelectorButton(composerSurface, composerRect) : null;
    if (modelButton) {
      const modelRect = modelButton.getBoundingClientRect();
      const left = modelRect.left - composerRect.left - BUBBLE_SIZE - BUBBLE_GAP;
      if (left >= BUBBLE_GAP) {
        return getBubblePlacementBesideRect(modelRect, composerRect, left);
      }
    }

    const rowButtons = getChatGptComposerButtonCandidates(composerRect);
    const actionButton = rowButtons[rowButtons.length - 1];

    if (actionButton) {
      const left = actionButton.rect.left - composerRect.left - BUBBLE_SIZE - BUBBLE_GAP;
      if (left >= BUBBLE_GAP) {
        return getBubblePlacementBesideRect(actionButton.rect, composerRect, left);
      }
    }

    return getBottomRightRowBubblePlacement(composerRect, 64);
  }

  function getChatGptComposerButtonCandidates(composerRect) {
    const rowTop = composerRect.bottom - Math.max(60, composerRect.height * 0.55);

    return Array.from(document.querySelectorAll("button, [role='button']"))
      .filter((button) => button.id !== BUBBLE_ID && !isContextGeneratorNode(button) && isVisible(button))
      .map((button) => ({ button, rect: button.getBoundingClientRect() }))
      .filter(({ rect }) => {
        return (
          rect.width > 0 &&
          rect.width <= 84 &&
          rect.height > 0 &&
          rect.height <= 72 &&
          rect.left >= composerRect.left + composerRect.width * 0.45 &&
          rect.right <= composerRect.right + 12 &&
          rect.top >= rowTop &&
          rect.bottom <= composerRect.bottom + 12
        );
      })
      .sort((a, b) => a.rect.left - b.rect.left);
  }

  function getGrokBubblePlacement(composerRect) {
    const speedButton = findGrokSpeedSelectorButton(composerRect);
    if (speedButton) {
      const speedRect = speedButton.getBoundingClientRect();
      const left = speedRect.left - composerRect.left - BUBBLE_SIZE - BUBBLE_GAP;
      if (left >= BUBBLE_GAP) {
        return getBubblePlacementBesideRect(speedRect, composerRect, left);
      }
    }

    const safeButtons = getGrokComposerButtonCandidates(composerRect).filter(({ button }) => {
      const label = getElementLabel(button, true);
      return !/\b(send|submit|voice|mic|microphone)\b/.test(label);
    });
    const anchorButton = safeButtons[safeButtons.length - 1];

    if (anchorButton) {
      const left = anchorButton.rect.left - composerRect.left - BUBBLE_SIZE - BUBBLE_GAP;
      if (left >= BUBBLE_GAP) {
        return getBubblePlacementBesideRect(anchorButton.rect, composerRect, left);
      }
    }

    return getBottomRightRowBubblePlacement(composerRect, 186);
  }

  function findGrokSpeedSelectorButton(composerRect) {
    const rowTop = composerRect.bottom - Math.max(64, composerRect.height * 0.65);

    return Array.from(document.querySelectorAll("button, [role='button'], [tabindex='0']"))
      .filter((button) => button.id !== BUBBLE_ID && !isContextGeneratorNode(button) && isVisible(button))
      .map((button) => {
        const rect = button.getBoundingClientRect();
        const label = getElementLabel(button, true);
        const text = (button.innerText || button.textContent || "").toLowerCase();
        let score = 0;

        if (/\b(fast|auto|expert|think|thinking)\b/.test(text)) score += 180;
        if (/\b(mode|speed|model|reasoning|thinking)\b/.test(label)) score += 36;
        if (rect.left >= composerRect.left + composerRect.width * 0.55) score += 22;
        if (rect.width >= 42 && rect.width <= 150) score += 12;
        if (/\b(send|submit|voice|mic|microphone|attach|upload|image|search)\b/.test(label)) score -= 180;

        return { button, rect, score };
      })
      .filter(({ rect, score }) => {
        return (
          score >= 120 &&
          rect.width > 0 &&
          rect.height > 0 &&
          rect.height <= 56 &&
          rect.left >= composerRect.left + composerRect.width * 0.45 &&
          rect.right <= composerRect.right + 12 &&
          rect.top >= rowTop &&
          rect.bottom <= composerRect.bottom + 12
        );
      })
      .sort((a, b) => {
        if (b.score !== a.score) return b.score - a.score;
        return b.rect.left - a.rect.left;
      })[0]?.button || null;
  }

  function getGrokComposerButtonCandidates(composerRect) {
    const rowTop = composerRect.bottom - Math.max(62, composerRect.height * 0.58);

    return Array.from(document.querySelectorAll("button, [role='button'], [tabindex='0']"))
      .filter((button) => button.id !== BUBBLE_ID && !isContextGeneratorNode(button) && isVisible(button))
      .map((button) => ({ button, rect: button.getBoundingClientRect() }))
      .filter(({ rect }) => {
        return (
          rect.width > 0 &&
          rect.width <= 88 &&
          rect.height > 0 &&
          rect.height <= 72 &&
          rect.left >= composerRect.left + composerRect.width * 0.35 &&
          rect.right <= composerRect.right + 12 &&
          rect.top >= rowTop &&
          rect.bottom <= composerRect.bottom + 12
        );
      })
      .sort((a, b) => a.rect.left - b.rect.left);
  }

  function getDeepSeekBubblePlacement(composerRect) {
    const rowButtons = getDeepSeekComposerButtonCandidates(composerRect);
    if (rowButtons.length < 2) return getDeepSeekFallbackBubblePlacement(composerRect);

    const pinButton = rowButtons[rowButtons.length - 2];
    const left = pinButton.rect.left - composerRect.left - BUBBLE_SIZE - BUBBLE_GAP;
    if (left < BUBBLE_GAP) return getDeepSeekFallbackBubblePlacement(composerRect);

    return getBubblePlacementBesideRect(pinButton.rect, composerRect, left);
  }

  function getDeepSeekFallbackBubblePlacement(composerRect) {
    return getBottomRightRowBubblePlacement(composerRect, 104);
  }

  function findGeminiModelSelectorButton(composerRect) {
    if (!composerRect) return null;

    const rowTop = composerRect.bottom - Math.max(64, composerRect.height * 0.65);

    return Array.from(document.querySelectorAll("button, [role='button'], [tabindex='0'], [aria-label], [title], span"))
      .filter((element) => element.id !== BUBBLE_ID && !isContextGeneratorNode(element) && isVisible(element))
      .map((element) => {
        const rect = element.getBoundingClientRect();
        const label = getElementLabel(element, true);
        const text = (element.innerText || element.textContent || "").toLowerCase();
        let score = 0;

        if (/\bflash\b/.test(text)) score += 220;
        if (/\bflash\b/.test(label)) score += 220;
        if (/\b(model|gemini|pro|thinking)\b/.test(label)) score += 36;
        if (rect.left >= composerRect.left + composerRect.width * 0.45) score += 16;
        if (rect.width >= 24 && rect.width <= 180) score += 10;
        if (/\b(send|submit|voice|mic|microphone|attach|upload|image|gallery|add)\b/.test(label)) score -= 260;

        return { element, rect, score };
      })
      .filter(({ rect, score }) => {
        return (
          score >= 180 &&
          rect.width > 0 &&
          rect.width <= 180 &&
          rect.height > 0 &&
          rect.height <= 72 &&
          rect.left >= composerRect.left + composerRect.width * 0.35 &&
          rect.right <= composerRect.right + 12 &&
          rect.top >= rowTop &&
          rect.bottom <= composerRect.bottom + 12
        );
      })
      .sort((a, b) => {
        if (b.score !== a.score) return b.score - a.score;
        return a.rect.left - b.rect.left;
      })[0]?.element || null;
  }

  function getGeminiBubblePlacement(composerRect, actionBtn) {
    const maxRight = Math.max(BUBBLE_GAP, composerRect.width - BUBBLE_SIZE - BUBBLE_GAP);
    const maxBottom = Math.max(BUBBLE_GAP, composerRect.height - BUBBLE_SIZE - BUBBLE_GAP);
    const fallback = {
      right: Math.round(Math.min(maxRight, BUBBLE_SLOT_WIDTH)),
      bottom: Math.round(Math.min(maxBottom, 16))
    };

    if (!actionBtn) return fallback;

    const actionRect = actionBtn.getBoundingClientRect();
    if (actionRect.width <= 0 || actionRect.height <= 0) return fallback;

    const right = Math.max(
      BUBBLE_GAP,
      Math.min(maxRight, composerRect.right - actionRect.left + BUBBLE_GAP)
    );
    const bottom = Math.max(
      BUBBLE_GAP,
      Math.min(
        maxBottom,
        composerRect.bottom - actionRect.bottom + (actionRect.height - BUBBLE_SIZE) / 2
      )
    );

    return {
      right: Math.round(right),
      bottom: Math.round(bottom)
    };
  }

  function getBubblePlacementBesideRect(targetRect, composerRect, left) {
    const top = Math.max(
      BUBBLE_GAP,
      Math.min(
        targetRect.top + (targetRect.height - BUBBLE_SIZE) / 2 - composerRect.top,
        composerRect.height - BUBBLE_SIZE - BUBBLE_GAP
      )
    );

    return {
      left: Math.round(left),
      top: Math.round(top)
    };
  }

  function getBottomRightRowBubblePlacement(composerRect, rightOffset) {
    const left = Math.max(
      BUBBLE_GAP,
      composerRect.width - BUBBLE_SIZE - rightOffset
    );
    const top = Math.max(
      BUBBLE_GAP,
      composerRect.height - BUBBLE_SIZE - 16
    );

    return {
      left: Math.round(left),
      top: Math.round(top)
    };
  }

  function setBubbleStylesIfChanged(bubble, styles) {
    Object.entries(styles).forEach(([property, value]) => {
      if (bubble.style[property] !== value) {
        bubble.style[property] = value;
      }
    });
  }

  function clampNumber(value, min, max) {
    if (!Number.isFinite(value)) return min;
    return Math.min(Math.max(value, min), max);
  }

  function getDeepSeekComposerButtonCandidates(composerRect) {
    const rowTop = composerRect.bottom - Math.max(64, composerRect.height * 0.55);

    return Array.from(document.querySelectorAll("button, [role='button'], [tabindex='0']"))
      .filter((button) => button.id !== BUBBLE_ID && !isContextGeneratorNode(button) && isVisible(button))
      .map((button) => ({ button, rect: button.getBoundingClientRect() }))
      .filter(({ rect }) => {
        return (
          rect.width > 0 &&
          rect.width <= 80 &&
          rect.height > 0 &&
          rect.height <= 72 &&
          rect.left >= composerRect.left + composerRect.width * 0.35 &&
          rect.right <= composerRect.right + 12 &&
          rect.top >= rowTop &&
          rect.bottom <= composerRect.bottom + 12
        );
      })
      .sort((a, b) => a.rect.left - b.rect.left);
  }

  function getGrokComposerButtonCandidates(composerRect) {
    const rowTop = composerRect.bottom - Math.max(64, composerRect.height * 0.55);

    return Array.from(document.querySelectorAll("button, [role='button'], [tabindex='0']"))
      .filter((button) => {
        const label = getElementLabel(button, true);
        return (
          button.id !== BUBBLE_ID &&
          !isContextGeneratorNode(button) &&
          isVisible(button) &&
          !isDisabled(button) &&
          !/\b(stop|cancel|attach|upload|voice|mic|microphone|new|menu|profile|account|model|mode)\b/.test(label)
        );
      })
      .map((button) => ({ button, rect: button.getBoundingClientRect() }))
      .filter(({ rect }) => {
        return (
          rect.width > 0 &&
          rect.width <= 84 &&
          rect.height > 0 &&
          rect.height <= 76 &&
          rect.left >= composerRect.left + composerRect.width * 0.45 &&
          rect.right <= composerRect.right + 16 &&
          rect.top >= rowTop &&
          rect.bottom <= composerRect.bottom + 16
        );
      })
      .sort((a, b) => a.rect.left - b.rect.left);
  }

  function findComposerSurfaceElement(input) {
    const inputRect = input?.getBoundingClientRect();
    if (!inputRect) return null;

    const candidates = getPlatformComposerCandidates(input, inputRect);
    let node = input.parentElement;

    while (node && node !== document.body) {
      const rect = node.getBoundingClientRect();
      if (isComposerSurfaceCandidate(node, rect, inputRect)) {
        candidates.push({ node, rect });
      }
      node = node.parentElement;
    }

    const bestCandidate = pickComposerSurfaceCandidate(candidates, input);
    if (bestCandidate) return bestCandidate;

    const form = input.closest("form");
    const formRect = form?.getBoundingClientRect();
    if (formRect && isComposerSurfaceCandidate(form, formRect, inputRect)) {
      return form;
    }

    return input.parentElement;
  }

  function getPlatformComposerCandidates(input, inputRect) {
    const selectors = currentPlatform.composerSelectors || [];
    const candidates = [];

    selectors.forEach((selector) => {
      const closest = input.closest(selector);
      if (closest) {
        const rect = closest.getBoundingClientRect();
        if (isComposerSurfaceCandidate(closest, rect, inputRect)) {
          candidates.push({ node: closest, rect, preferred: true });
        }
      }

      document.querySelectorAll(selector).forEach((element) => {
        if (!element.contains(input)) return;
        const rect = element.getBoundingClientRect();
        if (isComposerSurfaceCandidate(element, rect, inputRect)) {
          candidates.push({ node: element, rect, preferred: true });
        }
      });
    });

    return candidates.filter((candidate, index, all) => {
      return all.findIndex((other) => other.node === candidate.node) === index;
    });
  }

  function isComposerSurfaceCandidate(element, rect, inputRect) {
    if (!element || !rect || !inputRect || isContextGeneratorNode(element)) return false;

    const maxWidth = getMaxComposerSurfaceWidth();
    return (
      rect.width >= 280 &&
      rect.width <= maxWidth &&
      rect.height >= 40 &&
      rect.height <= 260 &&
      rect.left <= inputRect.left + 96 &&
      rect.right >= inputRect.right - 18 &&
      rect.top <= inputRect.top + 80 &&
      rect.bottom >= inputRect.bottom - 18
    );
  }

  function getMaxComposerSurfaceWidth() {
    return Math.min(currentPlatform.maxComposerWidth || DEFAULT_MAX_COMPOSER_WIDTH, window.innerWidth - 24);
  }

  function pickComposerSurfaceCandidate(candidates, input) {
    if (!candidates.length) return null;

    return candidates
      .map((candidate) => ({
        ...candidate,
        score: scoreComposerSurfaceCandidate(candidate, input)
      }))
      .sort((a, b) => b.score - a.score)[0].node;
  }

  function scoreComposerSurfaceCandidate(candidate, input) {
    const inputRect = input.getBoundingClientRect();
    const rect = candidate.rect;
    const buttonCount = Array.from(candidate.node.querySelectorAll("button"))
      .filter((button) => button.id !== BUBBLE_ID && isVisible(button)).length;

    let score = candidate.preferred ? 40 : 0;
    score += Math.min(buttonCount, 4) * 34;
    if (rect.width >= inputRect.width + 120) score += 28;
    if (rect.width <= inputRect.width + 44) score -= 34;
    if (rect.height <= 180) score += 18;

    if (currentPlatform.id === "chatgpt" || currentPlatform.id === "deepseek") {
      if (rect.bottom >= inputRect.bottom + 48) score += 140;
      if (rect.height < 92) score -= 120;
    }

    score -= (rect.width * rect.height) / 22000;

    return score;
  }

  function reserveComposerSurface(surface) {
    if (!surface) return;

    if (reservedComposerSurface && reservedComposerSurface !== surface) {
      releaseComposerSurface();
    }

    if (!surface.hasAttribute("data-context-generator-original-position")) {
      surface.setAttribute("data-context-generator-original-position", surface.style.position || "");
    }

    if (getComputedStyle(surface).position === "static") {
      surface.style.position = "relative";
    }

    reservedComposerSurface = surface;
  }

  function releaseComposerSurface() {
    if (!reservedComposerSurface) return;

    const originalPosition = reservedComposerSurface.getAttribute("data-context-generator-original-position") || "";
    reservedComposerSurface.style.position = originalPosition;
    reservedComposerSurface.removeAttribute("data-context-generator-original-position");
    reservedComposerSurface = null;
  }

  function reserveBubbleSlot(actionBtn, input) {
    const cluster = findActionCluster(actionBtn, input);
    reserveBubbleSlotForCluster(cluster);
  }

  function reserveBubbleSlotForCluster(cluster, slotWidth = BUBBLE_SLOT_WIDTH) {
    if (!cluster) return;

    releaseClaudeInlineControlSlots();
    if (reservedActionCluster && reservedActionCluster !== cluster) {
      releaseActionClusterSlot();
    }

    if (!cluster.hasAttribute("data-context-generator-original-transform")) {
      cluster.setAttribute("data-context-generator-original-transform", cluster.style.transform || "");
    }

    const originalTransform = cluster.getAttribute("data-context-generator-original-transform") || "";
    const targetTransform = `${originalTransform} translateX(-${slotWidth}px)`.trim();
    if (cluster.style.transform !== targetTransform) {
      cluster.style.transform = targetTransform;
    }
    if (cluster.style.willChange !== "transform") {
      cluster.style.willChange = "transform";
    }
    reservedActionCluster = cluster;
  }

  function reserveClaudeInlineBubbleSlot(anchorControl, controls, input, composerRect, inlineShift = 0) {
    reserveClaudeInlineControls(
      getClaudeInlineControlsToShift(controls, anchorControl),
      getClaudeModelControlsToNudge(controls, anchorControl),
      inlineShift
    );
  }

  function reserveClaudeInlineControls(sideControls, modelControls = [], inlineShift = CLAUDE_INLINE_SLOT_WIDTH) {
    const shift = Math.max(0, Math.round(inlineShift));
    const offsetEntries = new Map();

    modelControls.forEach((control) => {
      if (!control.element) return;
      offsetEntries.set(control.element, getClaudeControlTargetOffset(control, shift));
    });

    sideControls.forEach((control) => {
      if (!control.element) return;
      offsetEntries.set(control.element, getClaudeControlTargetOffset(control, shift));
    });

    const elements = [...offsetEntries.keys()].filter((element) => offsetEntries.get(element) !== 0);
    const overflowElements = getClaudeModelOverflowElements(modelControls);

    if (elements.length === 0) {
      releaseClaudeInlineControlSlots();
      return;
    }

    if (reservedActionCluster) {
      releaseActionClusterSlot();
    }

    reservedClaudeInlineControls
      .filter((element) => !elements.includes(element))
      .forEach(restoreReservedTransform);

    reservedClaudeOverflowElements
      .filter((element) => !overflowElements.includes(element))
      .forEach(restoreReservedOverflow);

    overflowElements.forEach(reserveClaudeModelOverflow);

    elements.forEach((element) => {
      if (!element.hasAttribute("data-context-generator-original-transform")) {
        element.setAttribute("data-context-generator-original-transform", element.style.transform || "");
      }

      const originalTransform = element.getAttribute("data-context-generator-original-transform") || "";
      const offset = offsetEntries.get(element) || 0;
      const targetTransform = `${originalTransform} translateX(${offset}px)`.trim();
      if (element.style.transform !== targetTransform) {
        element.style.transform = targetTransform;
      }
      if (element.style.willChange !== "transform") {
        element.style.willChange = "transform";
      }
    });

    reservedClaudeInlineControls = elements;
    reservedClaudeInlineShift = shift;
    reservedClaudeControlOffsets = offsetEntries;
    reservedClaudeOverflowElements = overflowElements;
  }

  function getClaudeModelOverflowElements(modelControls) {
    const elements = [];

    modelControls.forEach((control) => {
      let node = control.element;
      let depth = 0;

      while (node && node !== document.body && depth < 4) {
        if (!elements.includes(node)) elements.push(node);
        node = node.parentElement;
        depth += 1;
      }
    });

    return elements;
  }

  function reserveClaudeModelOverflow(element) {
    if (!element.hasAttribute("data-context-generator-original-overflow")) {
      element.setAttribute("data-context-generator-original-overflow", element.style.overflow || "");
    }
    if (element.style.overflow !== "visible") {
      element.style.overflow = "visible";
    }
  }

  function getClaudeControlTargetOffset(control, inlineShift = 0) {
    if (isClaudeModelControl(control)) {
      return -CLAUDE_MODEL_LEFT_NUDGE;
    }
    if (isClaudeSideControl(control)) {
      return CLAUDE_SIDE_CONTROL_RIGHT_NUDGE - Math.max(0, Math.round(inlineShift));
    }
    return 0;
  }

  function getClaudeModelControlsToNudge(controls, anchorControl) {
    const anchorCenterY = anchorControl.rect.top + anchorControl.rect.height / 2;

    return controls.filter((control) => {
      const centerY = control.rect.top + control.rect.height / 2;
      return Math.abs(centerY - anchorCenterY) <= 28 && isClaudeModelControl(control);
    });
  }

  function isClaudeModelControl(control) {
    return /\b(model|sonnet|opus|haiku)\b/.test(control?.label || "");
  }

  function isClaudeSideControl(control) {
    return (
      control?.rect?.width <= 84 ||
      /\b(send|submit|mic|microphone|voice|speak|speech|talk|dictation|audio)\b/.test(control?.label || "")
    );
  }

  function getClaudeInlineControlsToShift(controls, anchorControl) {
    const anchorCenterY = anchorControl.rect.top + anchorControl.rect.height / 2;
    const minLeft = anchorControl.rect.left - 160;

    return controls.filter((control) => {
      const centerY = control.rect.top + control.rect.height / 2;
      if (Math.abs(centerY - anchorCenterY) > 28) return false;
      if (control.rect.right < minLeft) return false;
      if (/\b(attach|upload|file|project|sidebar|side bar|menu|navigation|toggle|model|sonnet|opus|haiku)\b/.test(control.label)) {
        return false;
      }
      return control === anchorControl || isClaudeSideControl(control);
    });
  }

  function findActionCluster(actionBtn, input) {
    let node = actionBtn.parentElement;
    let cluster = null;

    while (node && node !== document.body) {
      if (node.contains(input)) break;
      cluster = node;
      node = node.parentElement;
    }

    return cluster || actionBtn;
  }

  function releaseBubbleSlot() {
    releaseActionClusterSlot();
    releaseClaudeInlineControlSlots();
  }

  function releaseActionClusterSlot() {
    if (!reservedActionCluster) return;

    restoreReservedTransform(reservedActionCluster);
    reservedActionCluster = null;
  }

  function releaseClaudeInlineControlSlots() {
    if (!reservedClaudeInlineControls.length) return;

    reservedClaudeInlineControls.forEach(restoreReservedTransform);
    reservedClaudeOverflowElements.forEach(restoreReservedOverflow);
    reservedClaudeInlineControls = [];
    reservedClaudeInlineShift = 0;
    reservedClaudeControlOffsets = new Map();
    reservedClaudeOverflowElements = [];
  }

  function restoreReservedTransform(element) {
    if (!element) return;

    const originalTransform = element.getAttribute("data-context-generator-original-transform") || "";
    element.style.transform = originalTransform;
    element.style.willChange = "";
    element.removeAttribute("data-context-generator-original-transform");
  }

  function restoreReservedOverflow(element) {
    if (!element) return;

    const originalOverflow = element.getAttribute("data-context-generator-original-overflow") || "";
    element.style.overflow = originalOverflow;
    element.removeAttribute("data-context-generator-original-overflow");
  }

  function scheduleFloatingButtonUpdate() {
    if (floatingButtonMonitoringDisabled) return;
    if (isDestinationSheetOpen()) return;
    if (floatingButtonFrame) return;
    floatingButtonFrame = requestAnimationFrame(() => {
      floatingButtonFrame = null;
      if (floatingButtonMonitoringDisabled) return;
      if (isDestinationSheetOpen()) return;
      try {
        ensureFloatingButton();
        updateClaudeLimitNudge();
      } catch (error) {
        if (isExtensionContextInvalidated(error)) {
          disableFloatingButtonMonitoring();
          return;
        }
        throw error;
      }
    });
  }

  function isContextGeneratorNode(node) {
    return node instanceof Element && (
      node.id === BUBBLE_ID ||
      node.id === OVERLAY_ID ||
      node.id === ONBOARDING_ID ||
      node.id === ONBOARDING_STYLE_ID ||
      node.id === CLAUDE_LIMIT_NUDGE_ID ||
      node.id === "context-generator-styles" ||
      node.dataset.contextGeneratorOwned === "true" ||
      Boolean(node.closest?.(`#${BUBBLE_ID}, #${OVERLAY_ID}, #${ONBOARDING_ID}, #${CLAUDE_LIMIT_NUDGE_ID}, #context-generator-styles, #${DESTINATION_SHEET_ID}`))
    );
  }

  function isOwnDomMutation(mutation) {
    const changedNodes = [...mutation.addedNodes, ...mutation.removedNodes].filter((node) => node instanceof Element);
    return isContextGeneratorNode(mutation.target) || (changedNodes.length > 0 && changedNodes.every(isContextGeneratorNode));
  }

  function startFloatingButtonMonitoring() {
    if (floatingButtonObserver) floatingButtonObserver.disconnect();
    floatingButtonObserver = new MutationObserver((mutations) => {
      if (floatingButtonMonitoringDisabled) return;
      if (mutations.every(isOwnDomMutation)) return;
      scheduleFloatingButtonUpdate();
    });
    floatingButtonObserver.observe(document.body || document.documentElement, { childList: true, subtree: true });

    window.addEventListener("resize", scheduleFloatingButtonUpdate);
    document.addEventListener("visibilitychange", scheduleFloatingButtonUpdate);
    document.addEventListener("focusin", handleFloatingButtonFocusIn);
    scheduleFloatingButtonUpdate();
  }

  function disableFloatingButtonMonitoring() {
    floatingButtonMonitoringDisabled = true;
    if (floatingButtonFrame) {
      cancelAnimationFrame(floatingButtonFrame);
      floatingButtonFrame = null;
    }
    if (floatingButtonObserver) {
      floatingButtonObserver.disconnect();
      floatingButtonObserver = null;
    }

    window.removeEventListener("resize", scheduleFloatingButtonUpdate);
    document.removeEventListener("visibilitychange", scheduleFloatingButtonUpdate);
    document.removeEventListener("focusin", handleFloatingButtonFocusIn);
  }

  function handleFloatingButtonFocusIn(event) {
    if (isClaudeComposerFocusTarget(event.target)) {
      dismissClaudeLimitNudge();
    }
    scheduleFloatingButtonUpdate();
  }

  function resetRunningFlag() {
    isRunning = false;
    clearRunningResetTimer();
    hideOverlay();
  }

  function clearRunningResetTimer() {
    if (runningResetTimer) {
      clearTimeout(runningResetTimer);
      runningResetTimer = null;
    }
  }

  function waitForElement(getElement, timeoutMs, name) {
    const startedAt = Date.now();

    return new Promise((resolve, reject) => {
      const tick = () => {
        const element = getElement();
        if (element) {
          resolve(element);
          return;
        }

        if (Date.now() - startedAt > timeoutMs) {
          reject(new Error(`Timed out waiting for ${name}.`));
          return;
        }

        setTimeout(tick, 250);
      };

      tick();
    });
  }

  function delay(timeoutMs) {
    return new Promise((resolve) => setTimeout(resolve, timeoutMs));
  }

  function getElementLabel(element, includeText = false) {
    const parts = [
      element.getAttribute("aria-label"),
      element.getAttribute("title"),
      element.getAttribute("data-testid"),
      element.getAttribute("data-test-id"),
      element.getAttribute("data-message-author-role"),
      element.getAttribute("data-role"),
      element.getAttribute("placeholder"),
      element.getAttribute("data-placeholder"),
      element.getAttribute("role"),
      element.localName,
      element.id,
      element.className
    ];

    if (includeText) {
      parts.push(element.textContent || "");
    }

    return parts
      .filter(Boolean)
      .join(" ")
      .toLowerCase();
  }

  function getElementText(element) {
    return element.value || element.innerText || element.textContent || "";
  }

  function cleanText(text) {
    return text.replace(/\u00a0/g, " ").replace(/[ \t]+\n/g, "\n").trim();
  }

  function isVisible(element) {
    const rect = element.getBoundingClientRect();
    const style = window.getComputedStyle(element);
    return rect.width > 0 && rect.height > 0 && style.visibility !== "hidden" && style.display !== "none";
  }

  function isDisabled(element) {
    return (
      element.disabled ||
      element.getAttribute("aria-disabled") === "true" ||
      element.getAttribute("disabled") !== null ||
      element.dataset.disabled === "true"
    );
  }
})();
